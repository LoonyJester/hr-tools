﻿--
-- Скрипт сгенерирован Devart dbForge Studio for MySQL, Версия 7.2.53.0
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 6/23/2017 6:46:56 PM
-- Версия сервера: 5.7.17-log
-- Версия клиента: 4.1
--


-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установить режим SQL (SQL mode)
-- 
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

-- 
-- Установка базы данных по умолчанию
--
USE company;

--
-- Описание для таблицы aspnetroles
--
DROP TABLE IF EXISTS aspnetroles;
CREATE TABLE aspnetroles (
  Id VARCHAR(128) NOT NULL,
  Name VARCHAR(256) NOT NULL,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы aspnetuserlogins
--
DROP TABLE IF EXISTS aspnetuserlogins;
CREATE TABLE aspnetuserlogins (
  LoginProvider VARCHAR(128) NOT NULL,
  ProviderKey VARCHAR(128) NOT NULL,
  UserId VARCHAR(128) NOT NULL,
  PRIMARY KEY (LoginProvider, ProviderKey, UserId)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы aspnetuserroles
--
DROP TABLE IF EXISTS aspnetuserroles;
CREATE TABLE aspnetuserroles (
  UserId VARCHAR(128) NOT NULL,
  RoleId VARCHAR(128) NOT NULL,
  PRIMARY KEY (UserId, RoleId),
  CONSTRAINT FK_aspnetuserroles_RoleId FOREIGN KEY (RoleId)
    REFERENCES team_international.aspnetroles(Id) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT FK_aspnetuserroles_UserId FOREIGN KEY (UserId)
    REFERENCES team_international.aspnetusers(Id) ON DELETE CASCADE ON UPDATE RESTRICT
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы aspnetusers
--
DROP TABLE IF EXISTS aspnetusers;
CREATE TABLE aspnetusers (
  Id VARCHAR(128) NOT NULL,
  Email VARCHAR(256) DEFAULT NULL,
  EmailConfirmed TINYINT(1) DEFAULT NULL,
  PasswordHash VARCHAR(256) DEFAULT NULL,
  SecurityStamp VARCHAR(256) DEFAULT NULL,
  PhoneNumber VARCHAR(256) DEFAULT NULL,
  PhoneNumberConfirmed TINYINT(1) DEFAULT NULL,
  TwoFactorEnabled TINYINT(1) DEFAULT NULL,
  LockoutEndDateUtc DATETIME DEFAULT NULL,
  LockoutEnabled TINYINT(1) DEFAULT NULL,
  AccessFailedCount INT(11) NOT NULL,
  UserName VARCHAR(256) NOT NULL,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы auth_user
--
DROP TABLE IF EXISTS auth_user;
CREATE TABLE auth_user (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Subject CHAR(36) DEFAULT NULL,
  Login VARCHAR(250) NOT NULL,
  PasswordHash VARCHAR(250) NOT NULL,
  PasswordSalt VARCHAR(100) NOT NULL,
  Roles VARCHAR(1000) NOT NULL,
  FullName VARCHAR(250) DEFAULT NULL,
  IsActivated TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (Id),
  UNIQUE INDEX Login (Login),
  UNIQUE INDEX UserId (Subject)
)
ENGINE = INNODB
AUTO_INCREMENT = 15
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы clients
--
DROP TABLE IF EXISTS clients;
CREATE TABLE clients (
  Id VARCHAR(128) NOT NULL,
  Secret VARCHAR(255) NOT NULL,
  Name VARCHAR(100) NOT NULL,
  Active BIT(1) NOT NULL,
  RefreshTokenLifeTime INT(11) NOT NULL,
  AllowedOrigin VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы core_employee
--
DROP TABLE IF EXISTS core_employee;
CREATE TABLE core_employee (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  EmployeeId CHAR(36) NOT NULL,
  FullName VARCHAR(250) NOT NULL,
  FullNameCyrillic VARCHAR(255) DEFAULT NULL,
  PatronymicCyrillic VARCHAR(250) DEFAULT NULL,
  JobTitle VARCHAR(250) NOT NULL,
  DepartmentName VARCHAR(250) DEFAULT NULL,
  DepartmentId INT(11) DEFAULT NULL,
  Technology VARCHAR(250) DEFAULT NULL,
  ProjectName VARCHAR(250) DEFAULT NULL,
  ProjectId INT(11) DEFAULT NULL,
  CompanyEmail VARCHAR(150) NOT NULL,
  PersonalEmail VARCHAR(150) DEFAULT NULL,
  MessengerName VARCHAR(150) DEFAULT NULL,
  MessengerLogin VARCHAR(150) DEFAULT NULL,
  MobileNumber VARCHAR(20) DEFAULT NULL,
  AdditionalMobileNumber VARCHAR(20) DEFAULT NULL,
  Birthday DATE DEFAULT NULL,
  Status INT(11) NOT NULL,
  StartDate DATE NOT NULL,
  TerminationDate DATE DEFAULT NULL,
  DaysSkipped INT(11) DEFAULT 0,
  BioUrl VARCHAR(1000) DEFAULT NULL,
  Notes VARCHAR(500) DEFAULT NULL,
  PhotoUrl VARCHAR(1000) DEFAULT NULL,
  OfficeLocationId INT(11) DEFAULT NULL,
  UserId CHAR(36) DEFAULT NULL,
  IsDeleted TINYINT(1) DEFAULT 0,
  PRIMARY KEY (Id),
  CONSTRAINT FK_core_employee_core_officelocation_Id FOREIGN KEY (OfficeLocationId)
    REFERENCES team_international.core_officelocation(Id) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE = INNODB
AUTO_INCREMENT = 1
AVG_ROW_LENGTH = 1489
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы core_jobtitle
--
DROP TABLE IF EXISTS core_jobtitle;
CREATE TABLE core_jobtitle (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Name VARCHAR(255) NOT NULL,
  IsDeleted TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы core_officelocation
--
DROP TABLE IF EXISTS core_officelocation;
CREATE TABLE core_officelocation (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Country VARCHAR(100) DEFAULT NULL,
  City VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (Id),
  UNIQUE INDEX Country_City (Country, City)
)
ENGINE = INNODB
AUTO_INCREMENT = 3
AVG_ROW_LENGTH = 8192
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы core_technology
--
DROP TABLE IF EXISTS core_technology;
CREATE TABLE core_technology (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Name VARCHAR(255) NOT NULL,
  IsDeleted TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы messagesaudit
--
DROP TABLE IF EXISTS messagesaudit;
CREATE TABLE messagesaudit (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Message VARCHAR(5000) NOT NULL,
  Metadata VARCHAR(5000) NOT NULL,
  DateTime DATE NOT NULL,
  ThreadId INT(11) DEFAULT NULL,
  PRIMARY KEY (Id),
  UNIQUE INDEX Id (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 29
AVG_ROW_LENGTH = 1755
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы pa_department
--
DROP TABLE IF EXISTS pa_department;
CREATE TABLE pa_department (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Name VARCHAR(255) NOT NULL,
  Description VARCHAR(255) DEFAULT NULL,
  IsDeleted TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
AVG_ROW_LENGTH = 4096
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы pa_employee
--
DROP TABLE IF EXISTS pa_employee;
CREATE TABLE pa_employee (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  EmployeeId CHAR(36) NOT NULL,
  FullName VARCHAR(250) NOT NULL,
  JobTitle VARCHAR(255) NOT NULL,
  Technology VARCHAR(255) DEFAULT NULL,
  StartDate DATE NOT NULL,
  IsDeleted TINYINT(1) DEFAULT 0,
  PRIMARY KEY (Id),
  UNIQUE INDEX EmployeeId (EmployeeId)
)
ENGINE = INNODB
AUTO_INCREMENT = 4
AVG_ROW_LENGTH = 2730
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы pa_project
--
DROP TABLE IF EXISTS pa_project;
CREATE TABLE pa_project (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Name VARCHAR(255) NOT NULL,
  Description VARCHAR(255) DEFAULT NULL,
  StartDate DATE NOT NULL,
  EndDate DATE DEFAULT NULL,
  IsActive TINYINT(1) NOT NULL DEFAULT 1,
  IsDeleted TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
AVG_ROW_LENGTH = 4096
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы pa_projectassignment
--
DROP TABLE IF EXISTS pa_projectassignment;
CREATE TABLE pa_projectassignment (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  EmployeeId CHAR(36) NOT NULL,
  ProjectId INT(11) DEFAULT NULL,
  DepartmentId INT(11) NOT NULL,
  StartDate DATE NOT NULL,
  EndDate DATE DEFAULT NULL,
  AssignedForInPersents INT(3) DEFAULT NULL,
  BillableForInPersents INT(3) DEFAULT NULL,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 1
AVG_ROW_LENGTH = 4096
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы refreshtokens
--
DROP TABLE IF EXISTS refreshtokens;
CREATE TABLE refreshtokens (
  Id VARCHAR(128) NOT NULL,
  Subject VARCHAR(255) NOT NULL,
  ClientId VARCHAR(100) NOT NULL,
  IssuedUtc DATETIME NOT NULL,
  ExpiresUtc DATETIME NOT NULL,
  ProtectedTicket VARCHAR(255) NOT NULL,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы aspnetuserclaims
--
DROP TABLE IF EXISTS aspnetuserclaims;
CREATE TABLE aspnetuserclaims (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  UserId VARCHAR(128) NOT NULL,
  ClaimType VARCHAR(256) DEFAULT NULL,
  ClaimValue VARCHAR(256) DEFAULT NULL,
  PRIMARY KEY (Id),
  CONSTRAINT FK_auth_AspNetUsers_UserId FOREIGN KEY (UserId)
    REFERENCES aspnetusers(Id) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE = INNODB
AUTO_INCREMENT = 6
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

DELIMITER $$

--
-- Описание для процедуры auth_user_activate
--
DROP PROCEDURE IF EXISTS auth_user_activate$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE auth_user_activate(
  IN UserId char(36), 
  IN IsActivated tinyint(1)
  )
BEGIN
  UPDATE `auth_user`
  SET IsActivated = IsActivated

  WHERE `auth_user`.`Subject` = UserId;
END
$$

--
-- Описание для процедуры auth_user_create
--
DROP PROCEDURE IF EXISTS auth_user_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE auth_user_create(
  IN UserId char(36),
  IN Login varchar(250),
  IN FullName varchar(250),
  IN Roles varchar(500),
  IN PasswordHash varchar(250),
  IN PasswordSalt varchar(100)
)
BEGIN
  INSERT INTO `auth_user`
    (Subject
    ,Login
    ,PasswordHash
    ,PasswordSalt
    ,Roles
    ,FullName
    ,IsActivated
    )
  VALUES(
    UserId,
    Login,
    PasswordHash,
    PasswordSalt,
    Roles,
    FullName,
    true
    );
END
$$

--
-- Описание для процедуры auth_user_getByLogin
--
DROP PROCEDURE IF EXISTS auth_user_getByLogin$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE auth_user_getByLogin(IN Login varchar(250))
BEGIN
  SELECT
    au.Subject,
    au.Login,
    au.PasswordHash,
    au.PasswordSalt,
    au.Roles,
    au.FullName
  FROM auth_user as au
  WHERE au.Login = Login
    AND au.IsActivated = 1;
END
$$

--
-- Описание для процедуры auth_user_getBySubject
--
DROP PROCEDURE IF EXISTS auth_user_getBySubject$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE auth_user_getBySubject(IN Subject char(36))
BEGIN
  SELECT
    au.Subject,
    au.Login,
    au.PasswordHash,
    au.PasswordSalt,
    au.Roles,
    au.FullName
  FROM auth_user au
  WHERE au.Subject = Subject
    AND au.IsActivated = 1;
END
$$

--
-- Описание для процедуры auth_user_update
--
DROP PROCEDURE IF EXISTS auth_user_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE auth_user_update(
  IN UserId char(36),
  IN Login varchar(250),
  IN FullName varchar(250),
  IN Roles varchar(500)
)
BEGIN
  UPDATE `auth_user`
  SET Login = Login,
    FullName = FullName,
    Roles = Roles

  WHERE `auth_user`.`Subject` = UserId;
END
$$

--
-- Описание для процедуры auth_user_updateWithPassword
--
DROP PROCEDURE IF EXISTS auth_user_updateWithPassword$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE auth_user_updateWithPassword(
  IN UserId char(36),
  IN Login varchar(250),
  IN FullName varchar(250),
  IN Roles varchar(500),
  IN PasswordHash varchar(250),
  IN PasswordSalt varchar(100)
)
BEGIN
  UPDATE `auth_user`
  SET Login = Login,
    FullName = FullName,
    Roles = Roles,
    PasswordHash = PasswordHash,
    PasswordSalt = PasswordSalt

  WHERE `auth_user`.`Subject` = UserId;
END
$$

--
-- Описание для процедуры core_employee_create
--
DROP PROCEDURE IF EXISTS core_employee_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_create(
  IN EmployeeId char(36),
  IN FullName varchar(250),
  IN FullNameCyrillic varchar(250),
  IN PatronymicCyrillic varchar(250),
  IN JobTitle varchar(250),
  IN DepartmentName varchar(250),
  IN Technology varchar(250),
  IN ProjectName varchar(250),
  IN CompanyEmail varchar(150),
  IN PersonalEmail varchar(150),
  IN MessengerName varchar(150),
  IN MessengerLogin varchar(150),
  IN MobileNumber varchar(20),
  IN AdditionalMobileNumber varchar(20),
  IN Birthday date,
  IN Status int(11),
  IN StartDate date,
  IN TerminationDate date,
  IN DaysSkipped int,
  IN BioUrl varchar(500),
  IN Notes varchar(1000),
  IN PhotoUrl varchar(500),
  IN Country varchar(100),
  IN City varchar(100)
  )
BEGIN
  INSERT INTO `team_international`.`core_employee` (
    EmployeeId
    ,FullName
    ,FullNameCyrillic
    ,PatronymicCyrillic
    ,JobTitle
    ,DepartmentName
    ,Technology
    ,ProjectName
    ,CompanyEmail
    ,PersonalEmail
    ,MessengerName
    ,MessengerLogin
    ,MobileNumber
    ,AdditionalMobileNumber
    ,Birthday
    ,Status
    ,StartDate
    ,TerminationDate
    ,DaysSkipped
    ,BioUrl
    ,Notes
    ,PhotoUrl
    ,OfficeLocationId
    ,IsDeleted)
    VALUES (
     EmployeeId
    ,FullName
    ,FullNameCyrillic
    ,PatronymicCyrillic
    ,JobTitle
    ,DepartmentName
    ,Technology
    ,ProjectName
    ,CompanyEmail
    ,PersonalEmail
    ,MessengerName
    ,MessengerLogin
    ,MobileNumber
    ,AdditionalMobileNumber
    ,Birthday
    ,Status
    ,StartDate
    ,TerminationDate
    ,DaysSkipped
    ,BioUrl
    ,Notes
    ,PhotoUrl
    ,(SELECT o.`Id` FROM `core_officelocation` o WHERE o.Country = Country AND o.City = City)
    ,0 
    );
END
$$

--
-- Описание для процедуры core_employee_delete
--
DROP PROCEDURE IF EXISTS core_employee_delete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_delete(IN EmployeeId CHAR(36))
BEGIN
	UPDATE `core_employee`
	SET IsDeleted = 1

	WHERE `core_employee`.`EmployeeId` = EmployeeId;
END
$$

--
-- Описание для процедуры core_employee_deleteBioUrl
--
DROP PROCEDURE IF EXISTS core_employee_deleteBioUrl$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_deleteBioUrl(IN EmployeeId char(36))
BEGIN
  UPDATE `core_employee`
  SET 
    BioUrl = NULL
  WHERE `core_employee`.`EmployeeId` = EmployeeId;
END
$$

--
-- Описание для процедуры core_employee_deletePhotoUrl
--
DROP PROCEDURE IF EXISTS core_employee_deletePhotoUrl$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_deletePhotoUrl(IN EmployeeId char(36))
BEGIN
  UPDATE `core_employee`
  SET 
    PhotoUrl = NULL
  WHERE `core_employee`.`EmployeeId` = EmployeeId;
END
$$

--
-- Описание для процедуры core_employee_getAll
--
DROP PROCEDURE IF EXISTS core_employee_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_getAll( 
  IN CurrentPage int(1), 
  IN ItemsPerPage int(1),
  IN SortColumnName varchar(100),
  IN IsDescending bit,

  IN SearchKeyword varchar(500),
  IN CountryFilter varchar(100),
  IN CityFilter varchar(100),
  IN StatusFilter varchar(2)
  )
BEGIN
    DECLARE CurrentPageLimit int(1);
    SET CurrentPageLimit = (CurrentPage - 1) * ItemsPerPage;

  	SELECT e.`Id`, e.`EmployeeId`, e.`FullName`, e.`FullNameCyrillic`, e.`PatronymicCyrillic`, e.`JobTitle`, 
    e.`DepartmentName`, e.`DepartmentId`, e.`Technology`, e.`ProjectName`, e.`ProjectId`, e.`CompanyEmail`, 
    e.`PersonalEmail`, e.`MessengerName`, e.`MessengerLogin`, e.`MobileNumber`, e.`AdditionalMobileNumber`, e.`Birthday`, e.`Status`, 
    e.`StartDate`, e.`TerminationDate`, e.`DaysSkipped`, e.`BioUrl`, e.`Notes`, e.`PhotoUrl`, 
    o.`Id`, o.`Country`, o.`City`

    FROM `core_employee` as e
    LEFT JOIN  `core_officelocation` as o
    ON e.OfficeLocationId = o.Id

    WHERE (e.FullName LIKE CONCAT('%', SearchKeyword, '%')
      OR e.FullNameCyrillic LIKE CONCAT('%', SearchKeyword, '%')
      OR e.JobTitle LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`Technology` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`ProjectName` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`DepartmentName` LIKE CONCAT('%', SearchKeyword, '%')    
     )
  
      AND o.Country LIKE CONCAT('%', CountryFilter, '%')
      AND o.City LIKE CONCAT('%', CityFilter, '%')
      AND e.Status LIKE CONCAT('%', StatusFilter, '%')

      AND e.`IsDeleted` = 0

    ORDER BY
			CASE WHEN SortColumnName = 'FullName' AND IsDescending = 0 THEN e.FullName END,
			CASE WHEN SortColumnName = 'FullName' AND IsDescending = 1 THEN e.FullName END DESC,
			CASE WHEN SortColumnName = 'JobTitle' AND IsDescending = 0 THEN e.JobTitle END,
			CASE WHEN SortColumnName = 'JobTitle' AND IsDescending = 1 THEN e.JobTitle END DESC,
			CASE WHEN SortColumnName = 'Technology' AND IsDescending = 0 THEN e.Technology END,
			CASE WHEN SortColumnName = 'Technology' AND IsDescending = 1 THEN e.Technology END DESC,
			CASE WHEN SortColumnName = 'ProjectName' AND IsDescending = 0 THEN e.ProjectName END,
			CASE WHEN SortColumnName = 'ProjectName' AND IsDescending = 1 THEN e.ProjectName END DESC,
			CASE WHEN SortColumnName = 'DepartmentName' AND IsDescending = 0 THEN e.DepartmentName END,
			CASE WHEN SortColumnName = 'DepartmentName' AND IsDescending = 1 THEN e.DepartmentName END DESC
  
    LIMIT CurrentPageLimit, ItemsPerPage;

END
$$

--
-- Описание для процедуры core_employee_getAllAdmin
--
DROP PROCEDURE IF EXISTS core_employee_getAllAdmin$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_getAllAdmin( 
  IN CurrentPage int(1), 
  IN ItemsPerPage int(1),
  IN SortColumnName varchar(100),
  IN IsDescending bit,

  IN SearchKeyword varchar(500),
  IN CountryFilter varchar(100),
  IN CityFilter varchar(100),
  IN StatusFilter varchar(2)
  )
BEGIN
    DECLARE CurrentPageLimit int(1);
    SET CurrentPageLimit = (CurrentPage - 1) * ItemsPerPage;

  	SELECT e.`Id`, e.`EmployeeId`, e.`FullName`, e.`FullNameCyrillic`, e.`PatronymicCyrillic`, e.`JobTitle`, 
    e.`DepartmentName`, e.`DepartmentId`, e.`Technology`, e.`ProjectName`, e.`ProjectId`, e.`CompanyEmail`, 
    e.`PersonalEmail`, e.`MessengerName`, e.`MessengerLogin`, e.`MobileNumber`, e.`AdditionalMobileNumber`, e.`Birthday`, e.`Status`, 
    e.`StartDate`, e.`TerminationDate`, e.`DaysSkipped`, e.`BioUrl`, e.`Notes`, e.`PhotoUrl`, 
    o.`Id`, o.`Country`, o.`City`

    FROM `core_employee` as e
    LEFT JOIN  `core_officelocation` as o
    ON e.OfficeLocationId = o.Id

    WHERE (e.FullName LIKE CONCAT('%', SearchKeyword, '%')
      OR e.FullNameCyrillic LIKE CONCAT('%', SearchKeyword, '%')
      OR e.JobTitle LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`Technology` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`ProjectName` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`DepartmentName` LIKE CONCAT('%', SearchKeyword, '%')    
     )
  
      AND o.Country LIKE CONCAT('%', CountryFilter, '%')
      AND o.City LIKE CONCAT('%', CityFilter, '%')
      AND e.Status LIKE CONCAT('%', StatusFilter, '%')

      AND e.`IsDeleted` = 0

    ORDER BY
			CASE WHEN SortColumnName = 'FullName' AND IsDescending = 0 THEN e.FullName END,
			CASE WHEN SortColumnName = 'FullName' AND IsDescending = 1 THEN e.FullName END DESC,
			CASE WHEN SortColumnName = 'JobTitle' AND IsDescending = 0 THEN e.JobTitle END,
			CASE WHEN SortColumnName = 'JobTitle' AND IsDescending = 1 THEN e.JobTitle END DESC,
			CASE WHEN SortColumnName = 'Technology' AND IsDescending = 0 THEN e.Technology END,
			CASE WHEN SortColumnName = 'Technology' AND IsDescending = 1 THEN e.Technology END DESC,
			CASE WHEN SortColumnName = 'ProjectName' AND IsDescending = 0 THEN e.ProjectName END,
			CASE WHEN SortColumnName = 'ProjectName' AND IsDescending = 1 THEN e.ProjectName END DESC,
			CASE WHEN SortColumnName = 'DepartmentName' AND IsDescending = 0 THEN e.DepartmentName END,
			CASE WHEN SortColumnName = 'DepartmentName' AND IsDescending = 1 THEN e.DepartmentName END DESC
  
    LIMIT CurrentPageLimit, ItemsPerPage;

END
$$

--
-- Описание для процедуры core_employee_getAllCompanyEmailFullName
--
DROP PROCEDURE IF EXISTS core_employee_getAllCompanyEmailFullName$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_getAllCompanyEmailFullName(
  )
BEGIN
    SELECT
    e.`Id`,
    e.`FullName`,
    e.`CompanyEmail`
  FROM `core_employee` AS e
  WHERE e.`IsDeleted` = 0;
END
$$

--
-- Описание для процедуры core_employee_getByCompanyEmail
--
DROP PROCEDURE IF EXISTS core_employee_getByCompanyEmail$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_getByCompanyEmail( 
  IN CompanyEmail varchar(150)
  )
BEGIN
    SELECT e.`Id`, e.`EmployeeId`, e.`FullName`, e.`FullNameCyrillic`, e.`PatronymicCyrillic`, e.`JobTitle`, 
    e.`DepartmentName`, e.`DepartmentId`, e.`Technology`, e.`ProjectName`, e.`ProjectId`, e.`CompanyEmail`, 
    e.`PersonalEmail`, e.`MessengerName`, e.`MessengerLogin`, e.`MobileNumber`, e.`AdditionalMobileNumber`, e.`Birthday`, e.`Status`, 
    e.`StartDate`, e.`TerminationDate`, e.`DaysSkipped`, e.`BioUrl`, e.`Notes`, e.`PhotoUrl`, 
    o.`Id`, o.`Country`, o.`City`

    FROM `core_employee` as e
    LEFT JOIN  `core_officelocation` as o
    ON e.OfficeLocationId = o.Id

    WHERE e.CompanyEmail = CompanyEmail
      AND e.`IsDeleted` = 0;

END
$$

--
-- Описание для процедуры core_employee_getById
--
DROP PROCEDURE IF EXISTS core_employee_getById$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_getById( 
  IN EmployeeId char(36)
  )
BEGIN
    SELECT e.`Id`, e.`EmployeeId`, e.`FullName`, e.`FullNameCyrillic`, e.`PatronymicCyrillic`, e.`JobTitle`, 
    e.`DepartmentName`, e.`DepartmentId`, e.`Technology`, e.`ProjectName`, e.`ProjectId`, e.`CompanyEmail`, 
    e.`PersonalEmail`, e.`Skype`, e.`MobileNumber`, e.`AdditionalMobileNumber`, e.`Birthday`, e.`Status`, 
    e.`StartDate`, e.`TerminationDate`, e.`DaysSkipped`, e.`BioUrl`, e.`Notes`, e.`PhotoUrl`, 
    o.`Id`, o.`Country`, o.`City`

    FROM `team_international`.`core_employee` as e
    LEFT JOIN  `team_international`.`core_officelocation` as o
    ON e.OfficeLocationId = o.Id
  
	WHERE e.EmployeeId = EmployeeId; 
END
$$

--
-- Описание для процедуры core_employee_getTotalCount
--
DROP PROCEDURE IF EXISTS core_employee_getTotalCount$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_getTotalCount(
  IN SearchKeyword varchar(500),
  IN CountryFilter varchar(100),
  IN CityFilter varchar(100),
  IN StatusFilter varchar(2)
  )
BEGIN
  SELECT COUNT(e.Id)
   FROM `core_employee` as e
      LEFT JOIN `core_officelocation` AS o
      ON e.OfficeLocationId = o.Id
  WHERE (e.FullName LIKE CONCAT('%', SearchKeyword, '%')
      OR e.FullNameCyrillic LIKE CONCAT('%', SearchKeyword, '%')
      OR e.JobTitle LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`Technology` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`ProjectName` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`DepartmentName` LIKE CONCAT('%', SearchKeyword, '%')    
     )
  
      AND o.Country LIKE CONCAT('%', CountryFilter, '%')
      AND o.City LIKE CONCAT('%', CityFilter, '%')
      AND e.Status LIKE CONCAT('%', StatusFilter, '%')

      AND e.`IsDeleted` = 0;
END
$$

--
-- Описание для процедуры core_employee_search
--
DROP PROCEDURE IF EXISTS core_employee_search$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_search(
  IN SearchKeyword varchar(500),
  IN CountryFilter varchar(100),
  IN CityFilter varchar(100),
  IN StatusFilter varchar(2)
  )
BEGIN
  SELECT e.`Id`, e.`EmployeeId`, e.`FullName`, e.`FullNameCyrillic`, e.`PatronymicCyrillic`, e.`JobTitle`, 
    e.`DepartmentName`, e.`DepartmentId`, e.`Technology`, e.`ProjectName`, e.`ProjectId`, e.`CompanyEmail`, 
    e.`PersonalEmail`, e.`MessengerName`, e.`MessengerLogin`, e.`MobileNumber`, e.`AdditionalMobileNumber`, e.`Birthday`, e.`Status`, 
    e.`StartDate`, e.`TerminationDate`, e.`DaysSkipped`, e.`BioUrl`, e.`Notes`, e.`PhotoUrl`

    FROM `core_employee` as e
      LEFT JOIN `core_officelocation` AS o
      ON e.OfficeLocationId = o.Id

    WHERE (e.FullName LIKE CONCAT('%', SearchKeyword, '%')
      OR e.FullNameCyrillic LIKE CONCAT('%', SearchKeyword, '%')
      OR e.JobTitle LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`Technology` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`ProjectName` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`DepartmentName` LIKE CONCAT('%', SearchKeyword, '%')    
     )
  
      AND o.Country LIKE CONCAT('%', CountryFilter, '%')
      AND o.City LIKE CONCAT('%', CityFilter, '%')
      AND e.Status LIKE CONCAT('%', StatusFilter, '%')

      AND e.`IsDeleted` = 0;
END
$$

--
-- Описание для процедуры core_employee_update
--
DROP PROCEDURE IF EXISTS core_employee_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_update(
  IN EmployeeId char(36),
  IN FullName varchar(250),
  IN FullNameCyrillic varchar(250),
  IN PatronymicCyrillic varchar(250),
  IN JobTitle varchar(250),
  IN DepartmentName varchar(250),
  IN Technology varchar(250),
  IN ProjectName varchar(250),
  IN CompanyEmail varchar(150),
  IN PersonalEmail varchar(150),
  IN MessengerName varchar(150),
  IN MessengerLogin varchar(150),
  IN MobileNumber varchar(20),
  IN AdditionalMobileNumber varchar(20),
  IN Birthday date,
  IN Status int(11),
  IN StartDate date,
  IN TerminationDate date,
  IN DaysSkipped int,
  IN BioUrl varchar(500),
  IN Notes varchar(1000),
  IN PhotoUrl varchar(500),
  IN Country varchar(100),
  IN City varchar(100)
  )
BEGIN
  UPDATE `core_employee`
  SET FullName = FullName,
    FullNameCyrillic = FullNameCyrillic,
    PatronymicCyrillic = PatronymicCyrillic,
    JobTitle = JobTitle,
    DepartmentName = DepartmentName,
    Technology = Technology,
    ProjectName = ProjectName,
    CompanyEmail = CompanyEmail,
    PersonalEmail = PersonalEmail,
    MessengerName = MessengerName,
    MessengerLogin = MessengerLogin,
    MobileNumber = MobileNumber,
    AdditionalMobileNumber = AdditionalMobileNumber,
    Birthday = Birthday,
    Status = Status,
    StartDate = StartDate,
    TerminationDate = TerminationDate,
    DaysSkipped = DaysSkipped,
    BioUrl = BioUrl,
    Notes = Notes,
    PhotoUrl = PhotoUrl,
    OfficeLocationId = (SELECT o.`Id` FROM `core_officelocation` o WHERE o.Country = Country AND o.City = City) 

  WHERE `core_employee`.`EmployeeId` = EmployeeId;
END
$$

--
-- Описание для процедуры core_jobtitle_create
--
DROP PROCEDURE IF EXISTS core_jobtitle_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_jobtitle_create(
  IN Name varchar(255)
  )
BEGIN
  INSERT INTO core_jobtitle(
    Name
    )
    VALUES(
    Name
    );

  SELECT LAST_INSERT_ID();
END
$$

--
-- Описание для процедуры core_jobtitle_delete
--
DROP PROCEDURE IF EXISTS core_jobtitle_delete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_jobtitle_delete(
  IN Id int(11)
  )
BEGIN
  UPDATE core_jobtitle jt
  SET
    jt.IsDeleted = 1
  WHERE jt.Id = Id;
END
$$

--
-- Описание для процедуры core_jobTitle_getAll
--
DROP PROCEDURE IF EXISTS core_jobTitle_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_jobTitle_getAll()
BEGIN
   SELECT j.Id, j.Name
   FROM core_jobtitle j
   WHERE j.IsDeleted = 0;
END
$$

--
-- Описание для процедуры core_jobTitle_getByName
--
DROP PROCEDURE IF EXISTS core_jobTitle_getByName$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_jobTitle_getByName(
	IN Name varchar(255)
  )
BEGIN
  SELECT j.Id, j.Name
   FROM core_jobtitle j
   WHERE j.IsDeleted = 0;
END
$$

--
-- Описание для процедуры core_jobtitle_update
--
DROP PROCEDURE IF EXISTS core_jobtitle_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_jobtitle_update(
  IN Id int(11),
  IN Name varchar(255)
  )
BEGIN
  UPDATE core_jobtitle j
  SET
    j.Name = Name
  WHERE j.Id = Id;
END
$$

--
-- Описание для процедуры core_officelocation_getAll
--
DROP PROCEDURE IF EXISTS core_officelocation_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_officelocation_getAll()
BEGIN
  SELECT o.`Id`, o.`Country`, o.`City`
  FROM `core_officelocation` AS o;
END
$$

--
-- Описание для процедуры core_technology_create
--
DROP PROCEDURE IF EXISTS core_technology_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_technology_create(
  IN Name varchar(255)
  )
BEGIN
  INSERT INTO core_technology(
    Name
    )
    VALUES(
    Name
    );

  SELECT LAST_INSERT_ID();
END
$$

--
-- Описание для процедуры core_technology_delete
--
DROP PROCEDURE IF EXISTS core_technology_delete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_technology_delete(
  IN Id int(11)
  )
BEGIN
  UPDATE core_technology t
  SET
    t.IsDeleted = 1
  WHERE t.Id = Id;
END
$$

--
-- Описание для процедуры core_technology_getAll
--
DROP PROCEDURE IF EXISTS core_technology_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_technology_getAll(
  )
BEGIN
  SELECT t.Id, t.Name
  FROM core_technology t
  WHERE t.IsDeleted = 0;
END
$$

--
-- Описание для процедуры core_technology_getByName
--
DROP PROCEDURE IF EXISTS core_technology_getByName$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_technology_getByName(
	IN Name varchar(255)
  )
BEGIN
  SELECT
    t.Id,
    t.Name
  FROM core_technology t
  WHERE t.Name = Name AND t.IsDeleted = 0;
END
$$

--
-- Описание для процедуры core_technology_update
--
DROP PROCEDURE IF EXISTS core_technology_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_technology_update(
  IN Id int(11),
  IN Name varchar(255)
  )
BEGIN
  UPDATE core_technology t
  SET
    t.Name = Name
  WHERE t.Id = Id;
END
$$

--
-- Описание для процедуры core_user_activate
--
DROP PROCEDURE IF EXISTS core_user_activate$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_user_activate(
  IN UserId char(36), 
  IN IsActivated tinyint(1)
  )
BEGIN
  UPDATE `auth_user`
  SET IsActivated = IsActivated

  WHERE `auth_user`.Subject = UserId;
END
$$

--
-- Описание для процедуры core_user_assignUserToEmployee
--
DROP PROCEDURE IF EXISTS core_user_assignUserToEmployee$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_user_assignUserToEmployee(
  IN UserId char(36),
  IN Login varchar(250)
  )
BEGIN
  UPDATE `core_employee` ce
  SET ce.UserId = UserId
  WHERE ce.CompanyEmail = Login
    AND ce.IsDeleted = 0;
END
$$

--
-- Описание для процедуры core_user_create
--
DROP PROCEDURE IF EXISTS core_user_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_user_create(
  IN UserId char(36),
  IN Login varchar(250),
  IN FullName varchar(250),
  IN Roles varchar(500),
  IN PasswordHash varchar(250),
  IN PasswordSalt varchar(100)
  )
BEGIN
  INSERT INTO `auth_user`
    (UserId
    ,Login
    ,PasswordHash
    ,PasswordSalt
    ,Roles
    ,FullName
    ,IsActivated
    )
  VALUES(
    UserId,
    Login,
    PasswordHash,
    PasswordSalt,
    Roles,
    FullName,
    true
    );
END
$$

--
-- Описание для процедуры core_user_getAllAdmin
--
DROP PROCEDURE IF EXISTS core_user_getAllAdmin$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_user_getAllAdmin( 
  IN CurrentPage int(1), 
  IN ItemsPerPage int(1),

  IN SearchKeyword varchar(500),
  IN RolesFilter varchar(100),
  IN IsActivatedFilter varchar(1)
  )
BEGIN
    DECLARE CurrentPageLimit int(1);
    SET CurrentPageLimit = (CurrentPage - 1) * ItemsPerPage;

  	SELECT u.Subject, u.Login, u.Roles, u.FullName, u.IsActivated

    FROM `auth_user` AS u

    WHERE u.Login LIKE CONCAT('%', SearchKeyword, '%')  
      AND (RolesFilter IS NULL ||  u.Roles & RolesFilter = RolesFilter)
      AND u.IsActivated LIKE CONCAT('%', IsActivatedFilter, '%')

    ORDER BY u.IsActivated DESC, u.Login
  
    LIMIT CurrentPageLimit, ItemsPerPage;
END
$$

--
-- Описание для процедуры core_user_getTotalCount
--
DROP PROCEDURE IF EXISTS core_user_getTotalCount$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_user_getTotalCount(
  IN SearchKeyword varchar(500),
  IN RolesFilter varchar(100),
  IN IsActivatedFilter varchar(1))
BEGIN
  SELECT COUNT(u.Id)
   FROM `auth_user` as u
  WHERE u.Login LIKE CONCAT('%', SearchKeyword, '%')
	  AND (RolesFilter IS NULL ||  u.Roles & RolesFilter = RolesFilter)
      AND u.IsActivated LIKE CONCAT('%', IsActivatedFilter, '%');
END
$$

--
-- Описание для процедуры core_user_update
--
DROP PROCEDURE IF EXISTS core_user_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_user_update(
  IN UserId char(36),
  IN Login varchar(250),
  IN FullName varchar(250),
  IN Roles varchar(500)
  )
BEGIN
  UPDATE `auth_user`
  SET Login = Login,
    FullName = FullName,
    Roles = Roles

  WHERE `auth_user`.`Subject` = UserId;
END
$$

--
-- Описание для процедуры core_user_updateWithPassword
--
DROP PROCEDURE IF EXISTS core_user_updateWithPassword$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_user_updateWithPassword(
  IN UserId char(36),
  IN Login varchar(250),
  IN FullName varchar(250),
  IN Roles varchar(500),
  IN PasswordHash varchar(250),
  IN PasswordSalt varchar(100)
  )
BEGIN
  UPDATE `auth_user`
  SET Login = Login,
    FullName = FullName,
    Roles = Roles,
    PasswordHash = PasswordHash,
    PasswordSalt = PasswordSalt

  WHERE `auth_user`.`Subject` = UserId;
END
$$

--
-- Описание для процедуры messagesaudit_create
--
DROP PROCEDURE IF EXISTS messagesaudit_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE messagesaudit_create(
  IN Message varchar(5000),
  IN Metadata varchar(5000),
  IN DateTime date,
  IN ThreadId int
  )
BEGIN
  INSERT INTO messagesaudit
    (Message, Metadata, DateTime, ThreadId)
  VALUES(Message, Metadata, DateTime, ThreadId);
END
$$

--
-- Описание для процедуры pa_department_create
--
DROP PROCEDURE IF EXISTS pa_department_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_department_create(
  IN Name varchar(255),
  IN Description varchar(255)
  )
BEGIN
  INSERT INTO pa_department(
    Name,
    Description
    )
    VALUES(
    Name,
    Description
    );

	SELECT LAST_INSERT_ID();
END
$$

--
-- Описание для процедуры pa_department_delete
--
DROP PROCEDURE IF EXISTS pa_department_delete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_department_delete(
  IN Id varchar(255)
  )
BEGIN
  UPDATE pa_department d
  SET
    d.IsDeleted = 1
  WHERE d.Id = Id;
END
$$

--
-- Описание для процедуры pa_department_getAll
--
DROP PROCEDURE IF EXISTS pa_department_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_department_getAll()
BEGIN
  SELECT d.Id, d.Name, d.Description
  FROM pa_department d
  WHERE d.IsDeleted = 0;
END
$$

--
-- Описание для процедуры pa_department_getAllAdmin
--
DROP PROCEDURE IF EXISTS pa_department_getAllAdmin$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_department_getAllAdmin(
  IN SearchKeyword varchar(255)
  )
BEGIN
  SELECT d.Id, d.Name, d.Description
  FROM pa_department d
  WHERE 
    (d.Name LIKE CONCAT('%', SearchKeyword, '%')
    OR d.Description LIKE CONCAT('%', SearchKeyword, '%'))
  AND d.IsDeleted = 0;
END
$$

--
-- Описание для процедуры pa_department_getByName
--
DROP PROCEDURE IF EXISTS pa_department_getByName$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_department_getByName(IN Name varchar(255))
BEGIN
  SELECT pd.Id, pd.Name, pd.Description
  FROM pa_department pd
  WHERE pd.Name = Name AND pd.IsDeleted = 0;
END
$$

--
-- Описание для процедуры pa_department_update
--
DROP PROCEDURE IF EXISTS pa_department_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_department_update(
  IN Id int,
  IN Name varchar(255),
  IN Description varchar(255)
  )
BEGIN
  UPDATE pa_department d
  SET
    d.Name = Name,
    d.Description = Description
  WHERE d.Id = Id;
END
$$

--
-- Описание для процедуры pa_employee_create
--
DROP PROCEDURE IF EXISTS pa_employee_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_employee_create(
  IN EmployeeId char(36),
  IN FullName varchar(250),
  IN JobTitle varchar(250),
  IN Technology varchar(250),
  IN StartDate date
  )
BEGIN
  INSERT INTO pa_employee(
    EmployeeId
    ,FullName
    ,JobTitle
    ,Technology
	,StartDate
    )
    VALUES (
     EmployeeId
    ,FullName
    ,JobTitle
    ,Technology
	,StartDate
    );
END
$$

--
-- Описание для процедуры pa_employee_delete
--
DROP PROCEDURE IF EXISTS pa_employee_delete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_employee_delete(
  IN EmployeeId char(36)
  )
BEGIN
  UPDATE pa_employee e
  SET
    e.IsDeleted = 1
  WHERE e.EmployeeId = EmployeeId;
END
$$

--
-- Описание для процедуры pa_employee_getAllByNameAutocomplete
--
DROP PROCEDURE IF EXISTS pa_employee_getAllByNameAutocomplete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_employee_getAllByNameAutocomplete(
  IN NameAutocomplete varchar(250)
  )
BEGIN
  SELECT e.EmployeeId, e.FullName, e.JobTitle, e.Technology, e.StartDate,
	(SELECT SUM(pp.AssignedForInPersents) FROM pa_projectassignment pp WHERE pp.EmployeeId = e.EmployeeId) AS AssignedForInPersentsSum,
    (SELECT SUM(pp.BillableForInPersents) FROM pa_projectassignment pp WHERE pp.EmployeeId = e.EmployeeId) AS BillableForInPersentsSum

  FROM pa_employee as e

  WHERE e.FullName LIKE CONCAT('%', NameAutocomplete, '%')
    AND e.`IsDeleted` = 0;
END
$$

--
-- Описание для процедуры pa_employee_update
--
DROP PROCEDURE IF EXISTS pa_employee_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_employee_update(
  IN EmployeeId char(36),
  IN FullName varchar(250),
  IN JobTitle varchar(250),
  IN Technology varchar(250),
  IN StartDate date
  )
BEGIN
  UPDATE pa_employee e
  SET
    e.FullName = FullName,
    e.JobTitle = JobTitle,
    e.Technology = Technology,
	e.StartDate = StartDate
  WHERE e.EmployeeId = EmployeeId;
END
$$

--
-- Описание для процедуры pa_projectAssignment_create
--
DROP PROCEDURE IF EXISTS pa_projectAssignment_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_projectAssignment_create(IN EmployeeId char(36),
  IN ProjectId int(11),
  IN DepartmentId int(11),
  IN StartDate date,
  IN EndDate date,
  IN AssignedFor int(3),
  IN BillableFor int(3)
  )
BEGIN
  INSERT INTO pa_projectassignment(
    EmployeeId,
    ProjectId,
    DepartmentId,
    StartDate,
    EndDate,
    AssignedForInPersents,
    BillableForInPersents
    )
  VALUES(
    EmployeeId,
    ProjectId,
    DepartmentId,
    StartDate,
    EndDate,
    AssignedFor,
    BillableFor
  );

  SELECT LAST_INSERT_ID();
END
$$

--
-- Описание для процедуры pa_projectAssignment_getAll
--
DROP PROCEDURE IF EXISTS pa_projectAssignment_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_projectAssignment_getAll(
  IN CurrentPage int(1), 
  IN ItemsPerPage int(1),
  IN SortColumnName varchar(100),
  IN IsDescending bit,

  IN SearchKeyword varchar(500),
  IN EmployeeFullNameFilter varchar(255),
  IN EmployeeJobTitleFilter varchar(255),
  IN EmployeeTechnologyFilter varchar(255),
  IN ProjectFilter varchar(255),
  IN DepartmentFilter varchar(255),
  IN ShowOldAssignments boolean,
  IN ShowOldDeactivatedProjects boolean
  )
BEGIN
  DECLARE CurrentPageLimit int(1);
    SET CurrentPageLimit = (CurrentPage - 1) * ItemsPerPage;

  	SELECT 
      pa.Id, 
      pa.EmployeeId , 
      e.FullName AS 'EmployeeFullName', 
      e.JobTitle AS 'EmployeeJobTitle', 
      e.Technology AS 'EmployeeTechnology', 
      pa.ProjectId,
      p.Name AS 'ProjectName',
      pa.DepartmentId, 
      d.Name AS 'DepartmentName',
      pa.StartDate, pa.EndDate, pa.AssignedForInPersents, pa.BillableForInPersents,
	  (SELECT SUM(pp.AssignedForInPersents) FROM pa_projectassignment pp WHERE pp.EmployeeId = pa.EmployeeId) AS AssignedForInPersentsSum,
      (SELECT SUM(pp.BillableForInPersents) FROM pa_projectassignment pp WHERE pp.EmployeeId = pa.EmployeeId) AS BillableForInPersentsSum

    FROM pa_projectassignment as pa
      INNER JOIN  pa_employee as e
        ON e.EmployeeId = pa.EmployeeId AND e.IsDeleted = 0
      LEFT JOIN  pa_project as p
        ON pa.ProjectId = p.Id AND p.IsDeleted = 0
      INNER JOIN  pa_department as d
        ON pa.DepartmentId = d.Id AND d.IsDeleted = 0

    WHERE (e.FullName LIKE CONCAT('%', SearchKeyword, '%')
      OR e.JobTitle LIKE CONCAT('%', SearchKeyword, '%')
      OR e.Technology LIKE CONCAT('%', SearchKeyword, '%')
      OR p.Name LIKE CONCAT('%', SearchKeyword, '%')
      OR d.Name LIKE CONCAT('%', SearchKeyword, '%') 
     )

	 AND e.FullName LIKE CONCAT('%', EmployeeFullNameFilter, '%')
     AND e.JobTitle LIKE CONCAT('%', EmployeeJobTitleFilter, '%')
     AND ((EmployeeTechnologyFilter = '' AND e.Technology IS NULL) OR e.Technology LIKE CONCAT('%', EmployeeTechnologyFilter, '%'))
     AND ((ProjectFilter = '' AND p.Name IS NULL) OR p.Name LIKE CONCAT('%', ProjectFilter, '%'))
     AND d.Name LIKE CONCAT('%', DepartmentFilter, '%')
	 AND IF(ShowOldAssignments = true, 1, pa.EndDate IS NULL OR pa.EndDate >= UTC_DATE())
     AND IF(ShowOldDeactivatedProjects = true, 1, (p.EndDate IS NULL OR p.EndDate >= UTC_DATE()) AND (p.EndDate IS NULL OR p.IsActive = true))

     -- AND e.`IsDeleted` = 0

    ORDER BY
			CASE WHEN SortColumnName = 'employeeFullName' AND IsDescending = 0 THEN e.FullName END,
			CASE WHEN SortColumnName = 'employeeFullName' AND IsDescending = 1 THEN e.FullName END DESC,
			CASE WHEN SortColumnName = 'employeeJobTitle' AND IsDescending = 0 THEN e.JobTitle END,
			CASE WHEN SortColumnName = 'employeeJobTitle' AND IsDescending = 1 THEN e.JobTitle END DESC,
			CASE WHEN SortColumnName = 'employeeTechnology' AND IsDescending = 0 THEN e.Technology END,
			CASE WHEN SortColumnName = 'employeeTechnology' AND IsDescending = 1 THEN e.Technology END DESC,
			CASE WHEN SortColumnName = 'projectName' AND IsDescending = 0 THEN p.Name END,
			CASE WHEN SortColumnName = 'projectName' AND IsDescending = 1 THEN p.Name END DESC,
			CASE WHEN SortColumnName = 'departmentName' AND IsDescending = 0 THEN d.Name END,
			CASE WHEN SortColumnName = 'departmentName' AND IsDescending = 1 THEN d.Name END DESC,
			CASE WHEN SortColumnName = 'startDateToDisplay' AND IsDescending = 0 THEN pa.StartDate END,
			CASE WHEN SortColumnName = 'startDateToDisplay' AND IsDescending = 1 THEN pa.StartDate END DESC,
			CASE WHEN SortColumnName = 'endDateToDisplay' AND IsDescending = 0 THEN pa.EndDate END,
			CASE WHEN SortColumnName = 'endDateToDisplay' AND IsDescending = 1 THEN pa.EndDate END DESC,
			CASE WHEN SortColumnName = 'assignedForInPersents' AND IsDescending = 0 THEN pa.AssignedForInPersents END,
			CASE WHEN SortColumnName = 'assignedForInPersents' AND IsDescending = 1 THEN pa.AssignedForInPersents END DESC,
			CASE WHEN SortColumnName = 'billableForInPersents' AND IsDescending = 0 THEN pa.BillableForInPersents END,
			CASE WHEN SortColumnName = 'billableForInPersents' AND IsDescending = 1 THEN pa.BillableForInPersents END DESC
  
    LIMIT CurrentPageLimit, ItemsPerPage;
END
$$

--
-- Описание для процедуры pa_projectAssignment_getTotalCount
--
DROP PROCEDURE IF EXISTS pa_projectAssignment_getTotalCount$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_projectAssignment_getTotalCount(IN SearchKeyword varchar(500),
  IN EmployeeFullNameFilter varchar(255),
  IN EmployeeJobTitleFilter varchar(255),
  IN EmployeeTechnologyFilter varchar(255),
  IN ProjectFilter varchar(255),
  IN DepartmentFilter varchar(255),
  IN ShowOldAssignments boolean,
  IN ShowOldDeactivatedProjects boolean
  )
BEGIN

  	SELECT COUNT(pa.Id)

     FROM pa_projectassignment as pa
      INNER JOIN  pa_employee as e
        ON e.EmployeeId = pa.EmployeeId AND e.IsDeleted = 0
      LEFT JOIN  pa_project as p
        ON pa.ProjectId = p.Id AND p.IsDeleted = 0
      INNER JOIN  pa_department as d
        ON pa.DepartmentId = d.Id AND d.IsDeleted = 0


    WHERE (e.FullName LIKE CONCAT('%', SearchKeyword, '%')
      OR e.JobTitle LIKE CONCAT('%', SearchKeyword, '%')
      OR e.Technology LIKE CONCAT('%', SearchKeyword, '%')
      OR e.Technology LIKE CONCAT('%', SearchKeyword, '%')
      OR p.Name LIKE CONCAT('%', SearchKeyword, '%')
      OR d.Name LIKE CONCAT('%', SearchKeyword, '%')
  )

	AND e.FullName LIKE CONCAT('%', EmployeeFullNameFilter, '%')
     AND e.JobTitle LIKE CONCAT('%', EmployeeJobTitleFilter, '%')
     AND ((EmployeeTechnologyFilter = '' AND e.Technology IS NULL) OR e.Technology LIKE CONCAT('%', EmployeeTechnologyFilter, '%'))
     AND ((ProjectFilter = '' AND p.Name IS NULL) OR p.Name LIKE CONCAT('%', ProjectFilter, '%'))
     AND d.Name LIKE CONCAT('%', DepartmentFilter, '%')
	 AND IF(ShowOldAssignments = true, 1, pa.EndDate IS NULL OR pa.EndDate >= UTC_DATE())
     AND IF(ShowOldDeactivatedProjects = true, 1, (p.EndDate IS NULL OR p.EndDate >= UTC_DATE()) AND (p.EndDate IS NULL OR p.IsActive = true));

     -- AND e.`IsDeleted` = 0
END
$$

--
-- Описание для процедуры pa_projectAssignment_update
--
DROP PROCEDURE IF EXISTS pa_projectAssignment_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_projectAssignment_update(IN Id int(11),
  IN EmployeeId char(36),
  IN ProjectId int(11),
  IN DepartmentId int(11),
  IN StartDate date,
  IN EndDate date,
  IN AssignedFor int(11),
  IN BillableFor int(11)
  )
BEGIN
  UPDATE pa_projectassignment pa
  SET EmployeeId = EmployeeId,
    ProjectId = ProjectId,
    DepartmentId = DepartmentId,
    StartDate = StartDate,
    EndDate = EndDate,
    AssignedForInPersents = AssignedFor,
    BillableForInPersents = BillableFor

  WHERE pa.Id = Id;
END
$$

--
-- Описание для процедуры pa_project_activate
--
DROP PROCEDURE IF EXISTS pa_project_activate$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_activate(
  IN Id int(11),
  IN MakeActive boolean
  )
BEGIN
  UPDATE pa_project p
  SET
    p.IsActive = MakeActive
  WHERE p.Id = Id;
END
$$

--
-- Описание для процедуры pa_project_create
--
DROP PROCEDURE IF EXISTS pa_project_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_create(
  IN Name varchar(255),
  IN Description varchar(255),
  IN StartDate datetime,
  IN EndDate datetime
  )
BEGIN
  INSERT INTO pa_project(
    Name,
    Description,
    StartDate,
    EndDate
    )
    VALUES(
    Name,
    Description,
    StartDate,
    EndDate
    );

	SELECT LAST_INSERT_ID();
END
$$

--
-- Описание для процедуры pa_project_delete
--
DROP PROCEDURE IF EXISTS pa_project_delete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_delete(
  IN Id int
  )
BEGIN
  UPDATE pa_project p
  SET
    p.IsDeleted = 1
  WHERE p.Id = Id;
END
$$

--
-- Описание для процедуры pa_project_getAll
--
DROP PROCEDURE IF EXISTS pa_project_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_getAll(
  IN CurrentPage int(1), 
  IN ItemsPerPage int(1), 
  IN SortColumnName varchar(100), 
  IN IsDescending bit, 
  IN SearchKeyword varchar(500), 
  IN ShowOld bool,
  IN ShowDeactivated bool
  )
BEGIN
   DECLARE CurrentPageLimit int(1);
    SET CurrentPageLimit = (CurrentPage - 1) * ItemsPerPage;


  	SELECT p.Id, p.Name, p.Description, p.StartDate, p.EndDate, p.IsActive

    FROM pa_project as p

    WHERE (p.Name LIKE CONCAT('%', SearchKeyword, '%')
      OR p.Description LIKE CONCAT('%', SearchKeyword, '%'))
     
      AND p.`IsDeleted` = 0
      AND IF(ShowOld = true, 1, p.EndDate IS NULL OR p.EndDate > UTC_DATE())
	  AND IF(ShowDeactivated = true, 1, p.IsActive = true)

    ORDER BY
			CASE WHEN SortColumnName = 'Name' AND IsDescending = 0 THEN p.Name END,
			CASE WHEN SortColumnName = 'Name' AND IsDescending = 1 THEN p.Name END DESC,
			CASE WHEN SortColumnName = 'Description' AND IsDescending = 0 THEN p.Description END,
			CASE WHEN SortColumnName = 'Description' AND IsDescending = 1 THEN p.Description END DESC,
			CASE WHEN SortColumnName = 'StartDate' AND IsDescending = 0 THEN p.StartDate END,
			CASE WHEN SortColumnName = 'StartDate' AND IsDescending = 1 THEN p.StartDate END DESC,
			CASE WHEN SortColumnName = 'EndDate' AND IsDescending = 0 THEN p.EndDate END,
			CASE WHEN SortColumnName = 'EndDate' AND IsDescending = 1 THEN p.EndDate END DESC
  
    LIMIT CurrentPageLimit, ItemsPerPage;
END
$$

--
-- Описание для процедуры pa_project_getAllByNameAutocomplete
--
DROP PROCEDURE IF EXISTS pa_project_getAllByNameAutocomplete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_getAllByNameAutocomplete(
  IN NameAutocomplete varchar(20),
  IN ShowOld bool,
  IN ShowDeactivated bool
  )
BEGIN
	SELECT p.Id, p.Name, p.Description, p.StartDate, p.EndDate, p.IsActive

  FROM pa_project as p

  WHERE p.Name LIKE CONCAT('%', NameAutocomplete, '%')
    AND p.`IsDeleted` = 0
    AND IF(ShowOld = true, 1, p.EndDate IS NULL OR p.EndDate >= UTC_DATE())
	AND IF(ShowDeactivated = true, 1, p.IsActive = true);
END
$$

--
-- Описание для процедуры pa_project_getByName
--
DROP PROCEDURE IF EXISTS pa_project_getByName$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_getByName(IN Name varchar(255))
BEGIN
  SELECT p.Id, p.Name, p.Description, p.StartDate, p.EndDate, p.IsActive
  FROM pa_project p
  WHERE p.Name = Name AND p.IsDeleted = 0;
END
$$

--
-- Описание для процедуры pa_project_getTotalCount
--
DROP PROCEDURE IF EXISTS pa_project_getTotalCount$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_getTotalCount(
  IN SearchKeyword varchar(500),
  IN ShowOld bool
  )
BEGIN
	SELECT COUNT(p.Id)

    FROM pa_project as p

    WHERE (p.Name LIKE CONCAT('%', SearchKeyword, '%')
      OR p.Description LIKE CONCAT('%', SearchKeyword, '%'))
      AND IF(ShowOld = true, 1, p.EndDate IS NULL OR p.EndDate >= UTC_DATE())
      AND p.`IsDeleted` = 0;
END
$$

--
-- Описание для процедуры pa_project_update
--
DROP PROCEDURE IF EXISTS pa_project_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_update(
  IN Id int,
  IN Name varchar(255),
  IN Description varchar(255),
  IN StartDate datetime,
  IN EndDate datetime
  )
BEGIN
  UPDATE pa_project p
  SET
    p.Name = Name,
    p.Description = Description,
    p.StartDate = StartDate,
    p.EndDate = EndDate
  WHERE p.Id = Id;
END
$$

DELIMITER ;

-- 
-- Вывод данных для таблицы aspnetroles
--
INSERT INTO aspnetroles VALUES
('05c398b1-0134-4282-8e28-ad2d6b1c867c', 'SuperAdmin'),
('07395294-a603-48d1-891b-4cfb74e7bfae', 'Manager'),
('59227c63-bf62-4dd2-8096-aae05d55e1b3', 'Employee'),
('62e5eedb-b179-45f7-a2bd-20e24d8c6ab5', 'Recruiter'),
('78bb8c33-fb25-4562-8d08-479d4aeb4a74', 'Admin');

-- 
-- Вывод данных для таблицы aspnetuserlogins
--

-- Таблица company.aspnetuserlogins не содержит данных

-- 
-- Вывод данных для таблицы aspnetuserroles
--

-- Таблица company.aspnetuserroles не содержит данных

-- 
-- Вывод данных для таблицы aspnetusers
--
INSERT INTO aspnetusers VALUES
('1130780f-6ae3-4892-a478-52bd1b4322d5', 'Test user', 1, 'APP7xyDaorLLyf2hC1BmXz8kdQdPn7ZPj2CWXMI80opBvH6jC5WaWZMDJbiRF1kgQg==', '1879c685-921e-44c7-b8fb-a71f6ca2f90f', '1234', 0, 0, NULL, 1, 0, 'user@gmail.com');

-- 
-- Вывод данных для таблицы auth_user
--
INSERT INTO auth_user VALUES
(14, '179bc251-9e09-4fc3-9cda-5f0f58d3e91c', 'alice@mail.com', '+2/CGYi1HUEpK0aWnJrE47hULf4VZhaqzs6WCaIV4c4=', '5dyyBNxA1VmXp9k5VfyPhg==', '7', 'Alice F.', 1);

-- 
-- Вывод данных для таблицы clients
--

-- Таблица company.clients не содержит данных

-- 
-- Вывод данных для таблицы core_employee
--

-- Таблица company.core_employee не содержит данных

-- 
-- Вывод данных для таблицы core_jobtitle
--

-- Таблица company.core_jobtitle не содержит данных

-- 
-- Вывод данных для таблицы core_officelocation
--
INSERT INTO core_officelocation VALUES
(1, 'Ukraine', 'Kharkiv'),
(2, 'Ukraine', 'Lviv');

-- 
-- Вывод данных для таблицы core_technology
--

-- Таблица company.core_technology не содержит данных

-- 
-- Вывод данных для таблицы messagesaudit
--
INSERT INTO messagesaudit VALUES
(1, '{"EmployeeId":"444e0399-93f9-456b-8511-a1384604d0ee","FullName":"1","JobTitle":"dsf","Technology":null,"StartDate":"2017-04-09T00:00:00","EventId":"caa50000-3418-902b-3a44-08d497790711"}', '{"MessageId":"caa50000-3418-902b-3a44-08d497790711","ConversationId":"caa50000-3418-902b-cc67-08d497790713","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnensq3nbdkjq6gdg6?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(2, '{"EmployeeId":"444e0399-93f9-456b-8511-a1384604d0ee","FullName":"1","JobTitle":"dsf","Technology":null,"StartDate":"2017-04-08T00:00:00","EventId":"caa50000-3418-902b-8eb6-08d497792a38"}', '{"MessageId":"caa50000-3418-902b-8eb6-08d497792a38","ConversationId":"caa50000-3418-902b-9541-08d497792a38","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnensq3nbdkjq6gdg6?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(3, '{"EmployeeId":"444e0399-93f9-456b-8511-a1384604d0ee","FullName":"1","JobTitle":"dsf","Technology":null,"StartDate":"2017-04-07T00:00:00","EventId":"caa50000-3418-902b-d304-08d497797e32"}', '{"MessageId":"caa50000-3418-902b-d304-08d497797e32","ConversationId":"caa50000-3418-902b-d69c-08d497797e32","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnensq3nbdkjq6gdg6?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(4, '{"EmployeeId":"444e0399-93f9-456b-8511-a1384604d0ee","FullName":"1","JobTitle":"dsf","Technology":null,"StartDate":"2017-04-06T00:00:00","EventId":"caa50000-3418-902b-9c1b-08d49779a0c3"}', '{"MessageId":"caa50000-3418-902b-9c1b-08d49779a0c3","ConversationId":"caa50000-3418-902b-abd8-08d49779a3d6","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnensq3nbdkjq6gdg6?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(5, '{"EmployeeId":"444e0399-93f9-456b-8511-a1384604d0ee","FullName":"1","JobTitle":"dsf","Technology":null,"StartDate":"2017-04-05T00:00:00","EventId":"caa50000-3418-902b-b533-08d49783356c"}', '{"MessageId":"caa50000-3418-902b-b533-08d49783356c","ConversationId":"caa50000-3418-902b-674e-08d49783356f","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzd6jbdkjxyawd9?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(6, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","FullName":"Olha Dorozhko","JobTitle":"Developer2","Technology":null,"StartDate":"2017-03-04T00:00:00","EventId":"caa50000-3418-902b-9529-08d49783518c"}', '{"MessageId":"caa50000-3418-902b-9529-08d49783518c","ConversationId":"caa50000-3418-902b-e3e1-08d49783518e","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnensxs4bdkjxy4odm?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(7, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","FullName":"Olha Dorozhko","JobTitle":"Developer2","Technology":null,"StartDate":"2017-03-03T00:00:00","EventId":"caa50000-3418-902b-1f5c-08d497839177"}', '{"MessageId":"caa50000-3418-902b-1f5c-08d497839177","ConversationId":"caa50000-3418-902b-5a02-08d497839179","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzsxgbdkjxyhkn8?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(8, '{"EmployeeId":"444e0399-93f9-456b-8511-a1384604d0ee","FullName":"1","JobTitle":"dsf","Technology":null,"StartDate":"2017-04-04T00:00:00","EventId":"caa50000-3418-902b-b17c-08d49783ba00"}', '{"MessageId":"caa50000-3418-902b-b17c-08d49783ba00","ConversationId":"caa50000-3418-902b-b877-08d49783ba00","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzsxgbdkjxyhkn8?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(9, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","FullName":"Olha Dorozhko","JobTitle":"Developer2","Technology":null,"StartDate":"2017-03-02T00:00:00","EventId":"caa50000-3418-902b-507d-08d49783c6d5"}', '{"MessageId":"caa50000-3418-902b-507d-08d49783c6d5","ConversationId":"caa50000-3418-902b-52a3-08d49783c6d5","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzsxgbdkjxyhkn8?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(10, '{"EmployeeId":"ef7a848f-d7f8-4441-8820-bc0c5cb47e7f","FullName":"test","JobTitle":"qa","Technology":null,"StartDate":"2017-04-18T00:00:00","EventId":"caa50000-3418-902b-dec4-08d49783d686"}', '{"MessageId":"caa50000-3418-902b-dec4-08d49783d686","ConversationId":"caa50000-3418-902b-e284-08d49783d686","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzsxgbdkjxyhkn8?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(11, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","FullName":"Olha Dorozhko","JobTitle":"Developer2","Technology":null,"StartDate":"2017-03-01T00:00:00","EventId":"caa50000-3418-902b-d574-08d49783e936"}', '{"MessageId":"caa50000-3418-902b-d574-08d49783e936","ConversationId":"caa50000-3418-902b-d90c-08d49783e936","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzsxgbdkjxyhkn8?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(12, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","FullName":"Olha Dorozhko","JobTitle":"Developer2","Technology":null,"StartDate":"2017-02-28T00:00:00","EventId":"caa50000-3418-902b-b254-08d497840eba"}', '{"MessageId":"caa50000-3418-902b-b254-08d497840eba","ConversationId":"caa50000-3418-902b-b3c4-08d497840eba","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzsxgbdkjxyhkn8?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(13, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","FullName":"Olha Dorozhko","JobTitle":"Developer2","Technology":null,"StartDate":"2017-02-27T00:00:00","EventId":"caa50000-3418-902b-d789-08d49784275d"}', '{"MessageId":"caa50000-3418-902b-d789-08d49784275d","ConversationId":"caa50000-3418-902b-d95f-08d49784275d","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzsxgbdkjxyhkn8?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(14, '{"EmployeeId":"9a08797e-28ac-4ab5-b7e8-fe01a750ee3a","FullName":"test1","JobTitle":"dsf","Technology":null,"StartDate":"2017-04-19T00:00:00","EventId":"caa50000-3418-902b-fd0f-08d497842de8"}', '{"MessageId":"caa50000-3418-902b-fd0f-08d497842de8","ConversationId":"caa50000-3418-902b-fe53-08d497842de8","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzsxgbdkjxyhkn8?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(15, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","FullName":"Olha Dorozhko","JobTitle":"Developer2","Technology":null,"StartDate":"2017-02-26T00:00:00","EventId":"caa50000-3418-902b-42bb-08d497843776"}', '{"MessageId":"caa50000-3418-902b-42bb-08d497843776","ConversationId":"caa50000-3418-902b-4417-08d497843776","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzsxgbdkjxyhkn8?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(16, '{"EmployeeId":"ef7a848f-d7f8-4441-8820-bc0c5cb47e7f","FullName":"test","JobTitle":"qa","Technology":null,"StartDate":"2017-04-17T00:00:00","EventId":"caa50000-3418-902b-ecbd-08d497845dae"}', '{"MessageId":"caa50000-3418-902b-ecbd-08d497845dae","ConversationId":"caa50000-3418-902b-2110-08d497845db1","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnensgswbdkjxbnaya?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(17, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","FullName":"Olha Dorozhko","JobTitle":"Developer2","Technology":null,"StartDate":"2017-02-25T00:00:00","EventId":"caa50000-3418-902b-ee02-08d49785ce20"}', '{"MessageId":"caa50000-3418-902b-ee02-08d49785ce20","ConversationId":"caa50000-3418-902b-4e2c-08d49785ce23","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenz551bdkjxbqmyq?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(18, '{"EmployeeId":"9a6e2e47-e358-4709-9b8e-3ec545a398e2","FullName":"Test","JobTitle":"1","Technology":null,"StartDate":"2017-05-09T21:00:00Z","EventId":"caa50000-3418-902b-e2e0-08d497963ab1"}', '{"MessageId":"caa50000-3418-902b-e2e0-08d497963ab1","ConversationId":"caa50000-3418-902b-460a-08d497963ab4","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzg87bdkjxr9hgs?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeCreatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-26', 18),
(19, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","FullName":"Olha Dorozhko","JobTitle":"Developer2","Technology":null,"StartDate":"2017-02-24T00:00:00","EventId":"caa50000-3418-902b-d13b-08d4b1969034"}', '{"MessageId":"caa50000-3418-902b-d13b-08d4b1969034","ConversationId":"caa50000-3418-902b-071b-08d4b1969037","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-iisexpress-3k1oyybwdnenzz5ybdkmdftk8w?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-23', 17),
(20, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","EventId":"caa50000-3418-902b-3fa4-08d4b1969585"}', '{"MessageId":"caa50000-3418-902b-3fa4-08d4b1969585","ConversationId":"caa50000-3418-902b-6783-08d4b1969585","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-iisexpress-3k1oyybwdnenzz5ybdkmdftk8w?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeDeletedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-23', 17),
(21, '{"EmployeeId":"a6850ddd-62c5-47ab-a344-98206453300a","FullName":"sdf","JobTitle":"df","Technology":null,"StartDate":"2017-06-13T21:00:00Z","EventId":"caa50000-3418-902b-e8df-08d4b971099e"}', '{"MessageId":"caa50000-3418-902b-e8df-08d4b971099e","ConversationId":"caa50000-3418-902b-3dd9-08d4b97109a1","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzexibdkm15zddt?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeCreatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-23', 17),
(22, '{"EmployeeId":"a6850ddd-62c5-47ab-a344-98206453300a","FullName":"sdf","JobTitle":"df","Technology":null,"StartDate":"2017-06-13T00:00:00","EventId":"caa50000-3418-902b-11c9-08d4b97110ff"}', '{"MessageId":"caa50000-3418-902b-11c9-08d4b97110ff","ConversationId":"caa50000-3418-902b-3f81-08d4b97110ff","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzexibdkm15zddt?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-23', 17),
(23, '{"EmployeeId":"21bc617c-30e8-4795-ad21-324d99808b97","FullName":"TEst","JobTitle":"dd","Technology":null,"StartDate":"2017-06-07T21:00:00Z","EventId":"caa50000-3418-902b-d6f6-08d4b9a4ee6c"}', '{"MessageId":"caa50000-3418-902b-d6f6-08d4b9a4ee6c","ConversationId":"caa50000-3418-902b-6cdd-08d4b9a4ee6f","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzn4pbdkmuekpgi?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeCreatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-23', 17),
(24, '{"EmployeeId":"21bc617c-30e8-4795-ad21-324d99808b97","FullName":"TEst","JobTitle":"dd","Technology":null,"StartDate":"2017-06-07T00:00:00","EventId":"caa50000-3418-902b-0190-08d4b9a4f834"}', '{"MessageId":"caa50000-3418-902b-0190-08d4b9a4f834","ConversationId":"caa50000-3418-902b-4244-08d4b9a4f834","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzn4pbdkmuekpgi?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-23', 17),
(25, '{"EmployeeId":"21bc617c-30e8-4795-ad21-324d99808b97","FullName":"TEst","JobTitle":"dd","Technology":null,"StartDate":"2017-06-06T00:00:00","EventId":"caa50000-3418-902b-6e12-08d4b9a51d21"}', '{"MessageId":"caa50000-3418-902b-6e12-08d4b9a51d21","ConversationId":"caa50000-3418-902b-707a-08d4b9a51d21","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzn4pbdkmuekpgi?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-23', 17),
(26, '{"EmployeeId":"21bc617c-30e8-4795-ad21-324d99808b97","EventId":"caa50000-3418-902b-193f-08d4b9a526e5"}', '{"MessageId":"caa50000-3418-902b-193f-08d4b9a526e5","ConversationId":"caa50000-3418-902b-4411-08d4b9a526e5","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzn4pbdkmuekpgi?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeDeletedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-23', 17),
(27, '{"EmployeeId":"21bc617c-30e8-4795-ad21-324d99808b97","FullName":"TEst","JobTitle":"dd","Technology":"Android","StartDate":"2017-06-05T00:00:00","EventId":"caa50000-3418-902b-6ab5-08d4b9a55407"}', '{"MessageId":"caa50000-3418-902b-6ab5-08d4b9a55407","ConversationId":"caa50000-3418-902b-6c22-08d4b9a55407","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzn4pbdkmuekpgi?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-23', 17),
(28, '{"EmployeeId":"21bc617c-30e8-4795-ad21-324d99808b97","FullName":"TEst","JobTitle":"dd","Technology":"Android","StartDate":"2017-06-04T00:00:00","EventId":"caa50000-3418-902b-669d-08d4b9a563f7"}', '{"MessageId":"caa50000-3418-902b-669d-08d4b9a563f7","ConversationId":"caa50000-3418-902b-6870-08d4b9a563f7","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzn4pbdkmuekpgi?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-23', 17);

-- 
-- Вывод данных для таблицы pa_department
--

-- Таблица company.pa_department не содержит данных

-- 
-- Вывод данных для таблицы pa_employee
--
INSERT INTO pa_employee VALUES
(1, '9a6e2e47-e358-4709-9b8e-3ec545a398e2', 'Test', '1', NULL, '2017-05-09', 0),
(2, 'a6850ddd-62c5-47ab-a344-98206453300a', 'sdf', 'df', NULL, '2017-06-13', 0),
(3, '21bc617c-30e8-4795-ad21-324d99808b97', 'TEst', 'dd', 'Android', '2017-06-04', 1);

-- 
-- Вывод данных для таблицы pa_project
--

-- Таблица company.pa_project не содержит данных

-- 
-- Вывод данных для таблицы pa_projectassignment
--

-- Таблица company.pa_projectassignment не содержит данных

-- 
-- Вывод данных для таблицы refreshtokens
--

-- Таблица company.refreshtokens не содержит данных

-- 
-- Вывод данных для таблицы aspnetuserclaims
--
INSERT INTO aspnetuserclaims VALUES
(1, '1130780f-6ae3-4892-a478-52bd1b4322d5', 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role', 'SuperAdmin'),
(2, '1130780f-6ae3-4892-a478-52bd1b4322d5', 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role', 'Manager'),
(3, '1130780f-6ae3-4892-a478-52bd1b4322d5', 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role', 'Employee'),
(4, '1130780f-6ae3-4892-a478-52bd1b4322d5', 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role', 'Recruiter'),
(5, '1130780f-6ae3-4892-a478-52bd1b4322d5', 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role', 'Admin');

-- 
-- Восстановить предыдущий режим SQL (SQL mode)
-- 
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;