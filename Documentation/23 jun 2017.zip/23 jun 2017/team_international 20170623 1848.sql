﻿--
-- Скрипт сгенерирован Devart dbForge Studio for MySQL, Версия 7.2.53.0
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 6/23/2017 6:48:14 PM
-- Версия сервера: 5.7.17-log
-- Версия клиента: 4.1
--


-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установить режим SQL (SQL mode)
-- 
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

-- 
-- Установка базы данных по умолчанию
--
USE team_international;

--
-- Описание для таблицы aspnetroles
--
DROP TABLE IF EXISTS aspnetroles;
CREATE TABLE aspnetroles (
  Id VARCHAR(128) NOT NULL,
  Name VARCHAR(256) NOT NULL,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы aspnetusers
--
DROP TABLE IF EXISTS aspnetusers;
CREATE TABLE aspnetusers (
  Id VARCHAR(128) NOT NULL,
  Email VARCHAR(256) DEFAULT NULL,
  EmailConfirmed TINYINT(1) NOT NULL,
  PasswordHash VARCHAR(256) DEFAULT NULL,
  SecurityStamp VARCHAR(256) DEFAULT NULL,
  PhoneNumber VARCHAR(256) DEFAULT NULL,
  PhoneNumberConfirmed TINYINT(1) NOT NULL,
  TwoFactorEnabled TINYINT(1) DEFAULT NULL,
  LockoutEndDateUtc DATETIME DEFAULT NULL,
  LockoutEnabled TINYINT(1) DEFAULT NULL,
  AccessFailedCount INT(11) NOT NULL,
  UserName VARCHAR(256) NOT NULL,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы clients
--
DROP TABLE IF EXISTS clients;
CREATE TABLE clients (
  Id VARCHAR(128) NOT NULL,
  Secret VARCHAR(255) NOT NULL,
  Name VARCHAR(100) NOT NULL,
  Active BIT(1) NOT NULL,
  RefreshTokenLifeTime INT(11) NOT NULL,
  AllowedOrigin VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы core_jobtitle
--
DROP TABLE IF EXISTS core_jobtitle;
CREATE TABLE core_jobtitle (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Name VARCHAR(255) NOT NULL,
  IsDeleted TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 10
AVG_ROW_LENGTH = 8192
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы core_officelocation
--
DROP TABLE IF EXISTS core_officelocation;
CREATE TABLE core_officelocation (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Country VARCHAR(100) DEFAULT NULL,
  City VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (Id),
  UNIQUE INDEX Country_City (Country, City)
)
ENGINE = INNODB
AUTO_INCREMENT = 3
AVG_ROW_LENGTH = 8192
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы core_technology
--
DROP TABLE IF EXISTS core_technology;
CREATE TABLE core_technology (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Name VARCHAR(255) NOT NULL,
  IsDeleted TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 4
AVG_ROW_LENGTH = 8192
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы messagesaudit
--
DROP TABLE IF EXISTS messagesaudit;
CREATE TABLE messagesaudit (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Message VARCHAR(5000) NOT NULL,
  Metadata VARCHAR(5000) NOT NULL,
  DateTime DATE NOT NULL,
  ThreadId INT(11) DEFAULT NULL,
  PRIMARY KEY (Id),
  UNIQUE INDEX Id (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 14
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы pa_department
--
DROP TABLE IF EXISTS pa_department;
CREATE TABLE pa_department (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Name VARCHAR(255) NOT NULL,
  Description VARCHAR(255) DEFAULT NULL,
  IsDeleted TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 3
AVG_ROW_LENGTH = 4096
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы pa_employee
--
DROP TABLE IF EXISTS pa_employee;
CREATE TABLE pa_employee (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  EmployeeId CHAR(36) NOT NULL,
  FullName VARCHAR(250) NOT NULL,
  JobTitle VARCHAR(255) NOT NULL,
  Technology VARCHAR(255) DEFAULT NULL,
  StartDate DATE NOT NULL,
  IsDeleted TINYINT(1) DEFAULT 0,
  PRIMARY KEY (Id),
  UNIQUE INDEX EmployeeId (EmployeeId)
)
ENGINE = INNODB
AUTO_INCREMENT = 14
AVG_ROW_LENGTH = 2730
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы pa_project
--
DROP TABLE IF EXISTS pa_project;
CREATE TABLE pa_project (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  Name VARCHAR(255) NOT NULL,
  Description VARCHAR(255) DEFAULT NULL,
  StartDate DATE NOT NULL,
  EndDate DATE DEFAULT NULL,
  IsActive TINYINT(1) NOT NULL DEFAULT 1,
  IsDeleted TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 4
AVG_ROW_LENGTH = 4096
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы pa_projectassignment
--
DROP TABLE IF EXISTS pa_projectassignment;
CREATE TABLE pa_projectassignment (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  EmployeeId CHAR(36) NOT NULL,
  ProjectId INT(11) DEFAULT NULL,
  DepartmentId INT(11) NOT NULL,
  StartDate DATE NOT NULL,
  EndDate DATE DEFAULT NULL,
  AssignedForInPersents INT(3) DEFAULT NULL,
  BillableForInPersents INT(3) DEFAULT NULL,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 3
AVG_ROW_LENGTH = 4096
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы refreshtokens
--
DROP TABLE IF EXISTS refreshtokens;
CREATE TABLE refreshtokens (
  Id VARCHAR(128) NOT NULL,
  Subject VARCHAR(255) NOT NULL,
  ClientId VARCHAR(100) NOT NULL,
  IssuedUtc DATETIME NOT NULL,
  ExpiresUtc DATETIME NOT NULL,
  ProtectedTicket VARCHAR(500) NOT NULL,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы aspnetuserclaims
--
DROP TABLE IF EXISTS aspnetuserclaims;
CREATE TABLE aspnetuserclaims (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  UserId VARCHAR(128) NOT NULL,
  ClaimType VARCHAR(256) DEFAULT NULL,
  ClaimValue VARCHAR(256) DEFAULT NULL,
  PRIMARY KEY (Id),
  CONSTRAINT FK_auth_AspNetUsers_UserId FOREIGN KEY (UserId)
    REFERENCES aspnetusers(Id) ON DELETE CASCADE ON UPDATE RESTRICT
)
ENGINE = INNODB
AUTO_INCREMENT = 41
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы aspnetuserlogins
--
DROP TABLE IF EXISTS aspnetuserlogins;
CREATE TABLE aspnetuserlogins (
  LoginProvider VARCHAR(128) NOT NULL,
  ProviderKey VARCHAR(128) NOT NULL,
  UserId VARCHAR(128) NOT NULL,
  PRIMARY KEY (LoginProvider, ProviderKey, UserId),
  CONSTRAINT FK_aspnetuserlogins_UserId FOREIGN KEY (UserId)
    REFERENCES aspnetusers(Id) ON DELETE CASCADE ON UPDATE RESTRICT
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы aspnetuserroles
--
DROP TABLE IF EXISTS aspnetuserroles;
CREATE TABLE aspnetuserroles (
  UserId VARCHAR(128) NOT NULL,
  RoleId VARCHAR(128) NOT NULL,
  PRIMARY KEY (UserId, RoleId),
  CONSTRAINT FK_aspnetuserroles_RoleId FOREIGN KEY (RoleId)
    REFERENCES aspnetroles(Id) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT FK_aspnetuserroles_UserId FOREIGN KEY (UserId)
    REFERENCES aspnetusers(Id) ON DELETE CASCADE ON UPDATE RESTRICT
)
ENGINE = INNODB
AVG_ROW_LENGTH = 1365
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы core_employee
--
DROP TABLE IF EXISTS core_employee;
CREATE TABLE core_employee (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  EmployeeId CHAR(36) NOT NULL,
  FullName VARCHAR(250) NOT NULL,
  FullNameCyrillic VARCHAR(255) DEFAULT NULL,
  PatronymicCyrillic VARCHAR(250) DEFAULT NULL,
  JobTitle VARCHAR(250) NOT NULL,
  DepartmentName VARCHAR(250) DEFAULT NULL,
  DepartmentId INT(11) DEFAULT NULL,
  Technology VARCHAR(250) DEFAULT NULL,
  ProjectName VARCHAR(250) DEFAULT NULL,
  ProjectId INT(11) DEFAULT NULL,
  CompanyEmail VARCHAR(150) NOT NULL,
  PersonalEmail VARCHAR(150) DEFAULT NULL,
  MessengerName VARCHAR(150) DEFAULT NULL,
  MessengerLogin VARCHAR(150) DEFAULT NULL,
  MobileNumber VARCHAR(20) DEFAULT NULL,
  AdditionalMobileNumber VARCHAR(20) DEFAULT NULL,
  Birthday DATE DEFAULT NULL,
  Status INT(11) NOT NULL,
  StartDate DATE NOT NULL,
  TerminationDate DATE DEFAULT NULL,
  DaysSkipped INT(11) DEFAULT 0,
  BioUrl VARCHAR(1000) DEFAULT NULL,
  Notes VARCHAR(500) DEFAULT NULL,
  PhotoUrl VARCHAR(1000) DEFAULT NULL,
  OfficeLocationId INT(11) DEFAULT NULL,
  UserId CHAR(36) DEFAULT NULL,
  IsDeleted TINYINT(1) DEFAULT 0,
  PRIMARY KEY (Id),
  CONSTRAINT FK_core_employee_core_officelocation_Id FOREIGN KEY (OfficeLocationId)
    REFERENCES core_officelocation(Id) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE = INNODB
AUTO_INCREMENT = 58
AVG_ROW_LENGTH = 1489
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

DELIMITER $$

--
-- Описание для процедуры core_employee_create
--
DROP PROCEDURE IF EXISTS core_employee_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_create(
  IN EmployeeId char(36),
  IN FullName varchar(250),
  IN FullNameCyrillic varchar(250),
  IN PatronymicCyrillic varchar(250),
  IN JobTitle varchar(250),
  IN DepartmentName varchar(250),
  IN Technology varchar(250),
  IN ProjectName varchar(250),
  IN CompanyEmail varchar(150),
  IN PersonalEmail varchar(150),
  IN MessengerName varchar(150),
  IN MessengerLogin varchar(150),
  IN MobileNumber varchar(20),
  IN AdditionalMobileNumber varchar(20),
  IN Birthday date,
  IN Status int(11),
  IN StartDate date,
  IN TerminationDate date,
  IN DaysSkipped int,
  IN BioUrl varchar(500),
  IN Notes varchar(1000),
  IN PhotoUrl varchar(500),
  IN Country varchar(100),
  IN City varchar(100)
  )
BEGIN
  INSERT INTO `team_international`.`core_employee` (
    EmployeeId
    ,FullName
    ,FullNameCyrillic
    ,PatronymicCyrillic
    ,JobTitle
    ,DepartmentName
    ,Technology
    ,ProjectName
    ,CompanyEmail
    ,PersonalEmail
    ,MessengerName
    ,MessengerLogin
    ,MobileNumber
    ,AdditionalMobileNumber
    ,Birthday
    ,Status
    ,StartDate
    ,TerminationDate
    ,DaysSkipped
    ,BioUrl
    ,Notes
    ,PhotoUrl
    ,OfficeLocationId
    ,IsDeleted)
    VALUES (
     EmployeeId
    ,FullName
    ,FullNameCyrillic
    ,PatronymicCyrillic
    ,JobTitle
    ,DepartmentName
    ,Technology
    ,ProjectName
    ,CompanyEmail
    ,PersonalEmail
    ,MessengerName
    ,MessengerLogin
    ,MobileNumber
    ,AdditionalMobileNumber
    ,Birthday
    ,Status
    ,StartDate
    ,TerminationDate
    ,DaysSkipped
    ,BioUrl
    ,Notes
    ,PhotoUrl
    ,(SELECT o.`Id` FROM `core_officelocation` o WHERE o.Country = Country AND o.City = City)
    ,0 
    );
END
$$

--
-- Описание для процедуры core_employee_delete
--
DROP PROCEDURE IF EXISTS core_employee_delete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_delete(IN EmployeeId CHAR(36))
BEGIN
	UPDATE `core_employee`
	SET IsDeleted = 1

	WHERE `core_employee`.`EmployeeId` = EmployeeId;
END
$$

--
-- Описание для процедуры core_employee_deleteBioUrl
--
DROP PROCEDURE IF EXISTS core_employee_deleteBioUrl$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_deleteBioUrl(IN EmployeeId char(36))
BEGIN
  UPDATE `core_employee`
  SET 
    BioUrl = NULL
  WHERE `core_employee`.`EmployeeId` = EmployeeId;
END
$$

--
-- Описание для процедуры core_employee_deletePhotoUrl
--
DROP PROCEDURE IF EXISTS core_employee_deletePhotoUrl$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_deletePhotoUrl(IN EmployeeId char(36))
BEGIN
  UPDATE `core_employee`
  SET 
    PhotoUrl = NULL
  WHERE `core_employee`.`EmployeeId` = EmployeeId;
END
$$

--
-- Описание для процедуры core_employee_getAll
--
DROP PROCEDURE IF EXISTS core_employee_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_getAll( 
  IN CurrentPage int(1), 
  IN ItemsPerPage int(1),
  IN SortColumnName varchar(100),
  IN IsDescending bit,

  IN SearchKeyword varchar(500),
  IN CountryFilter varchar(100),
  IN CityFilter varchar(100),
  IN StatusFilter varchar(2)
  )
BEGIN
    DECLARE CurrentPageLimit int(1);
    SET CurrentPageLimit = (CurrentPage - 1) * ItemsPerPage;

  	SELECT e.`Id`, e.`EmployeeId`, e.`FullName`, e.`FullNameCyrillic`, e.`PatronymicCyrillic`, e.`JobTitle`, 
    e.`DepartmentName`, e.`DepartmentId`, e.`Technology`, e.`ProjectName`, e.`ProjectId`, e.`CompanyEmail`, 
    e.`PersonalEmail`, e.`MessengerName`, e.`MessengerLogin`, e.`MobileNumber`, e.`AdditionalMobileNumber`, e.`Birthday`, e.`Status`, 
    e.`StartDate`, e.`TerminationDate`, e.`DaysSkipped`, e.`BioUrl`, e.`Notes`, e.`PhotoUrl`, 
    o.`Id`, o.`Country`, o.`City`

    FROM `core_employee` as e
    LEFT JOIN  `core_officelocation` as o
    ON e.OfficeLocationId = o.Id

    WHERE (e.FullName LIKE CONCAT('%', SearchKeyword, '%')
      OR e.FullNameCyrillic LIKE CONCAT('%', SearchKeyword, '%')
      OR e.JobTitle LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`Technology` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`ProjectName` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`DepartmentName` LIKE CONCAT('%', SearchKeyword, '%')    
     )
  
      AND o.Country LIKE CONCAT('%', CountryFilter, '%')
      AND o.City LIKE CONCAT('%', CityFilter, '%')
      AND e.Status LIKE CONCAT('%', StatusFilter, '%')

      AND e.`IsDeleted` = 0

    ORDER BY
			CASE WHEN SortColumnName = 'FullName' AND IsDescending = 0 THEN e.FullName END,
			CASE WHEN SortColumnName = 'FullName' AND IsDescending = 1 THEN e.FullName END DESC,
			CASE WHEN SortColumnName = 'JobTitle' AND IsDescending = 0 THEN e.JobTitle END,
			CASE WHEN SortColumnName = 'JobTitle' AND IsDescending = 1 THEN e.JobTitle END DESC,
			CASE WHEN SortColumnName = 'Technology' AND IsDescending = 0 THEN e.Technology END,
			CASE WHEN SortColumnName = 'Technology' AND IsDescending = 1 THEN e.Technology END DESC,
			CASE WHEN SortColumnName = 'ProjectName' AND IsDescending = 0 THEN e.ProjectName END,
			CASE WHEN SortColumnName = 'ProjectName' AND IsDescending = 1 THEN e.ProjectName END DESC,
			CASE WHEN SortColumnName = 'DepartmentName' AND IsDescending = 0 THEN e.DepartmentName END,
			CASE WHEN SortColumnName = 'DepartmentName' AND IsDescending = 1 THEN e.DepartmentName END DESC
  
    LIMIT CurrentPageLimit, ItemsPerPage;

END
$$

--
-- Описание для процедуры core_employee_getAllAdmin
--
DROP PROCEDURE IF EXISTS core_employee_getAllAdmin$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_getAllAdmin( 
  IN CurrentPage int(1), 
  IN ItemsPerPage int(1),
  IN SortColumnName varchar(100),
  IN IsDescending bit,

  IN SearchKeyword varchar(500),
  IN CountryFilter varchar(100),
  IN CityFilter varchar(100),
  IN StatusFilter varchar(2)
  )
BEGIN
    DECLARE CurrentPageLimit int(1);
    SET CurrentPageLimit = (CurrentPage - 1) * ItemsPerPage;

  	SELECT e.`Id`, e.`EmployeeId`, e.`FullName`, e.`FullNameCyrillic`, e.`PatronymicCyrillic`, e.`JobTitle`, 
    e.`DepartmentName`, e.`DepartmentId`, e.`Technology`, e.`ProjectName`, e.`ProjectId`, e.`CompanyEmail`, 
    e.`PersonalEmail`, e.`MessengerName`, e.`MessengerLogin`, e.`MobileNumber`, e.`AdditionalMobileNumber`, e.`Birthday`, e.`Status`, 
    e.`StartDate`, e.`TerminationDate`, e.`DaysSkipped`, e.`BioUrl`, e.`Notes`, e.`PhotoUrl`, 
    o.`Id`, o.`Country`, o.`City`

    FROM `core_employee` as e
    LEFT JOIN  `core_officelocation` as o
    ON e.OfficeLocationId = o.Id

    WHERE (e.FullName LIKE CONCAT('%', SearchKeyword, '%')
      OR e.FullNameCyrillic LIKE CONCAT('%', SearchKeyword, '%')
      OR e.JobTitle LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`Technology` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`ProjectName` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`DepartmentName` LIKE CONCAT('%', SearchKeyword, '%')    
     )
  
      AND o.Country LIKE CONCAT('%', CountryFilter, '%')
      AND o.City LIKE CONCAT('%', CityFilter, '%')
      AND e.Status LIKE CONCAT('%', StatusFilter, '%')

      AND e.`IsDeleted` = 0

    ORDER BY
			CASE WHEN SortColumnName = 'FullName' AND IsDescending = 0 THEN e.FullName END,
			CASE WHEN SortColumnName = 'FullName' AND IsDescending = 1 THEN e.FullName END DESC,
			CASE WHEN SortColumnName = 'JobTitle' AND IsDescending = 0 THEN e.JobTitle END,
			CASE WHEN SortColumnName = 'JobTitle' AND IsDescending = 1 THEN e.JobTitle END DESC,
			CASE WHEN SortColumnName = 'Technology' AND IsDescending = 0 THEN e.Technology END,
			CASE WHEN SortColumnName = 'Technology' AND IsDescending = 1 THEN e.Technology END DESC,
			CASE WHEN SortColumnName = 'ProjectName' AND IsDescending = 0 THEN e.ProjectName END,
			CASE WHEN SortColumnName = 'ProjectName' AND IsDescending = 1 THEN e.ProjectName END DESC,
			CASE WHEN SortColumnName = 'DepartmentName' AND IsDescending = 0 THEN e.DepartmentName END,
			CASE WHEN SortColumnName = 'DepartmentName' AND IsDescending = 1 THEN e.DepartmentName END DESC
  
    LIMIT CurrentPageLimit, ItemsPerPage;

END
$$

--
-- Описание для процедуры core_employee_getAllCompanyEmailFullName
--
DROP PROCEDURE IF EXISTS core_employee_getAllCompanyEmailFullName$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_getAllCompanyEmailFullName(
  )
BEGIN
    SELECT
    e.`Id`,
    e.`FullName`,
    e.`CompanyEmail`
  FROM `core_employee` AS e
  WHERE e.`IsDeleted` = 0;
END
$$

--
-- Описание для процедуры core_employee_getByCompanyEmail
--
DROP PROCEDURE IF EXISTS core_employee_getByCompanyEmail$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_getByCompanyEmail( 
  IN CompanyEmail varchar(150)
  )
BEGIN
    SELECT e.`Id`, e.`EmployeeId`, e.`FullName`, e.`FullNameCyrillic`, e.`PatronymicCyrillic`, e.`JobTitle`, 
    e.`DepartmentName`, e.`DepartmentId`, e.`Technology`, e.`ProjectName`, e.`ProjectId`, e.`CompanyEmail`, 
    e.`PersonalEmail`, e.`MessengerName`, e.`MessengerLogin`, e.`MobileNumber`, e.`AdditionalMobileNumber`, e.`Birthday`, e.`Status`, 
    e.`StartDate`, e.`TerminationDate`, e.`DaysSkipped`, e.`BioUrl`, e.`Notes`, e.`PhotoUrl`, 
    o.`Id`, o.`Country`, o.`City`

    FROM `core_employee` as e
    LEFT JOIN  `core_officelocation` as o
    ON e.OfficeLocationId = o.Id

    WHERE e.CompanyEmail = CompanyEmail
      AND e.`IsDeleted` = 0;

END
$$

--
-- Описание для процедуры core_employee_getById
--
DROP PROCEDURE IF EXISTS core_employee_getById$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_getById( 
  IN EmployeeId char(36)
  )
BEGIN
    SELECT e.`Id`, e.`EmployeeId`, e.`FullName`, e.`FullNameCyrillic`, e.`PatronymicCyrillic`, e.`JobTitle`, 
    e.`DepartmentName`, e.`DepartmentId`, e.`Technology`, e.`ProjectName`, e.`ProjectId`, e.`CompanyEmail`, 
    e.`PersonalEmail`, e.`Skype`, e.`MobileNumber`, e.`AdditionalMobileNumber`, e.`Birthday`, e.`Status`, 
    e.`StartDate`, e.`TerminationDate`, e.`DaysSkipped`, e.`BioUrl`, e.`Notes`, e.`PhotoUrl`, 
    o.`Id`, o.`Country`, o.`City`

    FROM `team_international`.`core_employee` as e
    LEFT JOIN  `team_international`.`core_officelocation` as o
    ON e.OfficeLocationId = o.Id
  
	WHERE e.EmployeeId = EmployeeId; 
END
$$

--
-- Описание для процедуры core_employee_getTotalCount
--
DROP PROCEDURE IF EXISTS core_employee_getTotalCount$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_getTotalCount(
  IN SearchKeyword varchar(500),
  IN CountryFilter varchar(100),
  IN CityFilter varchar(100),
  IN StatusFilter varchar(2)
  )
BEGIN
  SELECT COUNT(e.Id)
   FROM `core_employee` as e
      LEFT JOIN `core_officelocation` AS o
      ON e.OfficeLocationId = o.Id
  WHERE (e.FullName LIKE CONCAT('%', SearchKeyword, '%')
      OR e.FullNameCyrillic LIKE CONCAT('%', SearchKeyword, '%')
      OR e.JobTitle LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`Technology` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`ProjectName` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`DepartmentName` LIKE CONCAT('%', SearchKeyword, '%')    
     )
  
      AND o.Country LIKE CONCAT('%', CountryFilter, '%')
      AND o.City LIKE CONCAT('%', CityFilter, '%')
      AND e.Status LIKE CONCAT('%', StatusFilter, '%')

      AND e.`IsDeleted` = 0;
END
$$

--
-- Описание для процедуры core_employee_search
--
DROP PROCEDURE IF EXISTS core_employee_search$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_search(
  IN SearchKeyword varchar(500),
  IN CountryFilter varchar(100),
  IN CityFilter varchar(100),
  IN StatusFilter varchar(2)
  )
BEGIN
  SELECT e.`Id`, e.`EmployeeId`, e.`FullName`, e.`FullNameCyrillic`, e.`PatronymicCyrillic`, e.`JobTitle`, 
    e.`DepartmentName`, e.`DepartmentId`, e.`Technology`, e.`ProjectName`, e.`ProjectId`, e.`CompanyEmail`, 
    e.`PersonalEmail`, e.`MessengerName`, e.`MessengerLogin`, e.`MobileNumber`, e.`AdditionalMobileNumber`, e.`Birthday`, e.`Status`, 
    e.`StartDate`, e.`TerminationDate`, e.`DaysSkipped`, e.`BioUrl`, e.`Notes`, e.`PhotoUrl`

    FROM `core_employee` as e
      LEFT JOIN `core_officelocation` AS o
      ON e.OfficeLocationId = o.Id

    WHERE (e.FullName LIKE CONCAT('%', SearchKeyword, '%')
      OR e.FullNameCyrillic LIKE CONCAT('%', SearchKeyword, '%')
      OR e.JobTitle LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`Technology` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`ProjectName` LIKE CONCAT('%', SearchKeyword, '%')
      OR e.`DepartmentName` LIKE CONCAT('%', SearchKeyword, '%')    
     )
  
      AND o.Country LIKE CONCAT('%', CountryFilter, '%')
      AND o.City LIKE CONCAT('%', CityFilter, '%')
      AND e.Status LIKE CONCAT('%', StatusFilter, '%')

      AND e.`IsDeleted` = 0;
END
$$

--
-- Описание для процедуры core_employee_update
--
DROP PROCEDURE IF EXISTS core_employee_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_employee_update(
  IN EmployeeId char(36),
  IN FullName varchar(250),
  IN FullNameCyrillic varchar(250),
  IN PatronymicCyrillic varchar(250),
  IN JobTitle varchar(250),
  IN DepartmentName varchar(250),
  IN Technology varchar(250),
  IN ProjectName varchar(250),
  IN CompanyEmail varchar(150),
  IN PersonalEmail varchar(150),
  IN MessengerName varchar(150),
  IN MessengerLogin varchar(150),
  IN MobileNumber varchar(20),
  IN AdditionalMobileNumber varchar(20),
  IN Birthday date,
  IN Status int(11),
  IN StartDate date,
  IN TerminationDate date,
  IN DaysSkipped int,
  IN BioUrl varchar(500),
  IN Notes varchar(1000),
  IN PhotoUrl varchar(500),
  IN Country varchar(100),
  IN City varchar(100)
  )
BEGIN
  UPDATE `core_employee`
  SET FullName = FullName,
    FullNameCyrillic = FullNameCyrillic,
    PatronymicCyrillic = PatronymicCyrillic,
    JobTitle = JobTitle,
    DepartmentName = DepartmentName,
    Technology = Technology,
    ProjectName = ProjectName,
    CompanyEmail = CompanyEmail,
    PersonalEmail = PersonalEmail,
    MessengerName = MessengerName,
    MessengerLogin = MessengerLogin,
    MobileNumber = MobileNumber,
    AdditionalMobileNumber = AdditionalMobileNumber,
    Birthday = Birthday,
    Status = Status,
    StartDate = StartDate,
    TerminationDate = TerminationDate,
    DaysSkipped = DaysSkipped,
    BioUrl = BioUrl,
    Notes = Notes,
    PhotoUrl = PhotoUrl,
    OfficeLocationId = (SELECT o.`Id` FROM `core_officelocation` o WHERE o.Country = Country AND o.City = City) 

  WHERE `core_employee`.`EmployeeId` = EmployeeId;
END
$$

--
-- Описание для процедуры core_jobtitle_create
--
DROP PROCEDURE IF EXISTS core_jobtitle_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_jobtitle_create(
  IN Name varchar(255)
  )
BEGIN
  INSERT INTO core_jobtitle(
    Name
    )
    VALUES(
    Name
    );

  SELECT LAST_INSERT_ID();
END
$$

--
-- Описание для процедуры core_jobtitle_delete
--
DROP PROCEDURE IF EXISTS core_jobtitle_delete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_jobtitle_delete(
  IN Id int(11)
  )
BEGIN
  UPDATE core_jobtitle jt
  SET
    jt.IsDeleted = 1
  WHERE jt.Id = Id;
END
$$

--
-- Описание для процедуры core_jobTitle_getAll
--
DROP PROCEDURE IF EXISTS core_jobTitle_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_jobTitle_getAll()
BEGIN
   SELECT j.Id, j.Name
   FROM core_jobtitle j
   WHERE j.IsDeleted = 0;
END
$$

--
-- Описание для процедуры core_jobTitle_getByName
--
DROP PROCEDURE IF EXISTS core_jobTitle_getByName$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_jobTitle_getByName(
	IN Name varchar(255)
  )
BEGIN
  SELECT j.Id, j.Name
   FROM core_jobtitle j
   WHERE j.Name = Name AND j.IsDeleted = 0;
END
$$

--
-- Описание для процедуры core_jobtitle_update
--
DROP PROCEDURE IF EXISTS core_jobtitle_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_jobtitle_update(
  IN Id int(11),
  IN Name varchar(255)
  )
BEGIN
  UPDATE core_jobtitle j
  SET
    j.Name = Name
  WHERE j.Id = Id;
END
$$

--
-- Описание для процедуры core_officelocation_getAll
--
DROP PROCEDURE IF EXISTS core_officelocation_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_officelocation_getAll()
BEGIN
  SELECT o.`Id`, o.`Country`, o.`City`
  FROM `core_officelocation` AS o;
END
$$

--
-- Описание для процедуры core_technology_create
--
DROP PROCEDURE IF EXISTS core_technology_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_technology_create(
  IN Name varchar(255)
  )
BEGIN
  INSERT INTO core_technology(
    Name
    )
    VALUES(
    Name
    );

  SELECT LAST_INSERT_ID();
END
$$

--
-- Описание для процедуры core_technology_delete
--
DROP PROCEDURE IF EXISTS core_technology_delete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_technology_delete(
  IN Id int(11)
  )
BEGIN
  UPDATE core_technology t
  SET
    t.IsDeleted = 1
  WHERE t.Id = Id;
END
$$

--
-- Описание для процедуры core_technology_getAll
--
DROP PROCEDURE IF EXISTS core_technology_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_technology_getAll(
  )
BEGIN
  SELECT t.Id, t.Name
  FROM core_technology t
  WHERE t.IsDeleted = 0;
END
$$

--
-- Описание для процедуры core_technology_getByName
--
DROP PROCEDURE IF EXISTS core_technology_getByName$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_technology_getByName(
	IN Name varchar(255)
  )
BEGIN
  SELECT
    t.Id,
    t.Name
  FROM core_technology t
  WHERE t.Name = Name AND t.IsDeleted = 0;
END
$$

--
-- Описание для процедуры core_technology_update
--
DROP PROCEDURE IF EXISTS core_technology_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_technology_update(
  IN Id int(11),
  IN Name varchar(255)
  )
BEGIN
  UPDATE core_technology t
  SET
    t.Name = Name
  WHERE t.Id = Id;
END
$$

--
-- Описание для процедуры core_user_activate
--
DROP PROCEDURE IF EXISTS core_user_activate$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_user_activate(
  IN UserId char(36), 
  IN IsActivated tinyint(1)
  )
BEGIN
  UPDATE `auth_user`
  SET IsActivated = IsActivated

  WHERE `auth_user`.Subject = UserId;
END
$$

--
-- Описание для процедуры core_user_assignUserToEmployee
--
DROP PROCEDURE IF EXISTS core_user_assignUserToEmployee$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_user_assignUserToEmployee(
  IN UserId char(36),
  IN Login varchar(250)
  )
BEGIN
  UPDATE `core_employee` ce
  SET ce.UserId = UserId
  WHERE ce.CompanyEmail = Login
    AND ce.IsDeleted = 0;
END
$$

--
-- Описание для процедуры core_user_create
--
DROP PROCEDURE IF EXISTS core_user_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_user_create(
  IN UserId char(36),
  IN Login varchar(250),
  IN FullName varchar(250),
  IN Roles varchar(500),
  IN PasswordHash varchar(250),
  IN PasswordSalt varchar(100)
  )
BEGIN
  INSERT INTO `auth_user`
    (UserId
    ,Login
    ,PasswordHash
    ,PasswordSalt
    ,Roles
    ,FullName
    ,IsActivated
    )
  VALUES(
    UserId,
    Login,
    PasswordHash,
    PasswordSalt,
    Roles,
    FullName,
    true
    );
END
$$

--
-- Описание для процедуры core_user_update
--
DROP PROCEDURE IF EXISTS core_user_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_user_update(
  IN UserId char(36),
  IN Login varchar(250),
  IN FullName varchar(250),
  IN Roles varchar(500)
  )
BEGIN
  UPDATE `auth_user`
  SET Login = Login,
    FullName = FullName,
    Roles = Roles

  WHERE `auth_user`.`Subject` = UserId;
END
$$

--
-- Описание для процедуры core_user_updateWithPassword
--
DROP PROCEDURE IF EXISTS core_user_updateWithPassword$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE core_user_updateWithPassword(
  IN UserId char(36),
  IN Login varchar(250),
  IN FullName varchar(250),
  IN Roles varchar(500),
  IN PasswordHash varchar(250),
  IN PasswordSalt varchar(100)
  )
BEGIN
  UPDATE `auth_user`
  SET Login = Login,
    FullName = FullName,
    Roles = Roles,
    PasswordHash = PasswordHash,
    PasswordSalt = PasswordSalt

  WHERE `auth_user`.`Subject` = UserId;
END
$$

--
-- Описание для процедуры messagesaudit_create
--
DROP PROCEDURE IF EXISTS messagesaudit_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE messagesaudit_create(
  IN Message varchar(5000),
  IN Metadata varchar(5000),
  IN DateTime date,
  IN ThreadId int
  )
BEGIN
  INSERT INTO messagesaudit
    (Message, Metadata, DateTime, ThreadId)
  VALUES(Message, Metadata, DateTime, ThreadId);
END
$$

--
-- Описание для процедуры pa_department_create
--
DROP PROCEDURE IF EXISTS pa_department_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_department_create(
  IN Name varchar(255),
  IN Description varchar(255)
  )
BEGIN
  INSERT INTO pa_department(
    Name,
    Description
    )
    VALUES(
    Name,
    Description
    );

	SELECT LAST_INSERT_ID();
END
$$

--
-- Описание для процедуры pa_department_delete
--
DROP PROCEDURE IF EXISTS pa_department_delete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_department_delete(
  IN Id varchar(255)
  )
BEGIN
  UPDATE pa_department d
  SET
    d.IsDeleted = 1
  WHERE d.Id = Id;
END
$$

--
-- Описание для процедуры pa_department_getAll
--
DROP PROCEDURE IF EXISTS pa_department_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_department_getAll()
BEGIN
  SELECT d.Id, d.Name, d.Description
  FROM pa_department d
  WHERE d.IsDeleted = 0;
END
$$

--
-- Описание для процедуры pa_department_getAllAdmin
--
DROP PROCEDURE IF EXISTS pa_department_getAllAdmin$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_department_getAllAdmin(
  IN SearchKeyword varchar(255)
  )
BEGIN
  SELECT d.Id, d.Name, d.Description
  FROM pa_department d
  WHERE 
    (d.Name LIKE CONCAT('%', SearchKeyword, '%')
    OR d.Description LIKE CONCAT('%', SearchKeyword, '%'))
  AND d.IsDeleted = 0;
END
$$

--
-- Описание для процедуры pa_department_getByName
--
DROP PROCEDURE IF EXISTS pa_department_getByName$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_department_getByName(IN Name varchar(255))
BEGIN
  SELECT pd.Id, pd.Name, pd.Description
  FROM pa_department pd
  WHERE pd.Name = Name AND pd.IsDeleted = 0;
END
$$

--
-- Описание для процедуры pa_department_update
--
DROP PROCEDURE IF EXISTS pa_department_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_department_update(
  IN Id int,
  IN Name varchar(255),
  IN Description varchar(255)
  )
BEGIN
  UPDATE pa_department d
  SET
    d.Name = Name,
    d.Description = Description
  WHERE d.Id = Id;
END
$$

--
-- Описание для процедуры pa_employee_create
--
DROP PROCEDURE IF EXISTS pa_employee_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_employee_create(
  IN EmployeeId char(36),
  IN FullName varchar(250),
  IN JobTitle varchar(250),
  IN Technology varchar(250),
  IN StartDate date
  )
BEGIN
  INSERT INTO pa_employee(
    EmployeeId
    ,FullName
    ,JobTitle
    ,Technology
	,StartDate
    )
    VALUES (
     EmployeeId
    ,FullName
    ,JobTitle
    ,Technology
	,StartDate
    );
END
$$

--
-- Описание для процедуры pa_employee_delete
--
DROP PROCEDURE IF EXISTS pa_employee_delete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_employee_delete(
  IN EmployeeId char(36)
  )
BEGIN
  UPDATE pa_employee e
  SET
    e.IsDeleted = 1
  WHERE e.EmployeeId = EmployeeId;
END
$$

--
-- Описание для процедуры pa_employee_getAllByNameAutocomplete
--
DROP PROCEDURE IF EXISTS pa_employee_getAllByNameAutocomplete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_employee_getAllByNameAutocomplete(
  IN NameAutocomplete varchar(250)
  )
BEGIN
  SELECT e.EmployeeId, e.FullName, e.JobTitle, e.Technology, e.StartDate,
	(SELECT SUM(pp.AssignedForInPersents) FROM pa_projectassignment pp WHERE pp.EmployeeId = e.EmployeeId) AS AssignedForInPersentsSum,
    (SELECT SUM(pp.BillableForInPersents) FROM pa_projectassignment pp WHERE pp.EmployeeId = e.EmployeeId) AS BillableForInPersentsSum

  FROM pa_employee as e

  WHERE e.FullName LIKE CONCAT('%', NameAutocomplete, '%')
    AND e.`IsDeleted` = 0;
END
$$

--
-- Описание для процедуры pa_employee_update
--
DROP PROCEDURE IF EXISTS pa_employee_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_employee_update(
  IN EmployeeId char(36),
  IN FullName varchar(250),
  IN JobTitle varchar(250),
  IN Technology varchar(250),
  IN StartDate date
  )
BEGIN
  UPDATE pa_employee e
  SET
    e.FullName = FullName,
    e.JobTitle = JobTitle,
    e.Technology = Technology,
	e.StartDate = StartDate
  WHERE e.EmployeeId = EmployeeId;
END
$$

--
-- Описание для процедуры pa_projectAssignment_create
--
DROP PROCEDURE IF EXISTS pa_projectAssignment_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_projectAssignment_create(IN EmployeeId char(36),
  IN ProjectId int(11),
  IN DepartmentId int(11),
  IN StartDate date,
  IN EndDate date,
  IN AssignedFor int(3),
  IN BillableFor int(3)
  )
BEGIN
  INSERT INTO pa_projectassignment(
    EmployeeId,
    ProjectId,
    DepartmentId,
    StartDate,
    EndDate,
    AssignedForInPersents,
    BillableForInPersents
    )
  VALUES(
    EmployeeId,
    ProjectId,
    DepartmentId,
    StartDate,
    EndDate,
    AssignedFor,
    BillableFor
  );

  SELECT LAST_INSERT_ID();
END
$$

--
-- Описание для процедуры pa_projectAssignment_getAll
--
DROP PROCEDURE IF EXISTS pa_projectAssignment_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_projectAssignment_getAll(
  IN CurrentPage int(1), 
  IN ItemsPerPage int(1),
  IN SortColumnName varchar(100),
  IN IsDescending bit,

  IN SearchKeyword varchar(500),
  IN EmployeeFullNameFilter varchar(255),
  IN EmployeeJobTitleFilter varchar(255),
  IN EmployeeTechnologyFilter varchar(255),
  IN ProjectFilter varchar(255),
  IN DepartmentFilter varchar(255),
  IN ShowOldAssignments boolean,
  IN ShowOldDeactivatedProjects boolean
  )
BEGIN
  DECLARE CurrentPageLimit int(1);
    SET CurrentPageLimit = (CurrentPage - 1) * ItemsPerPage;

  	SELECT 
      pa.Id, 
      pa.EmployeeId , 
      e.FullName AS 'EmployeeFullName', 
      e.JobTitle AS 'EmployeeJobTitle', 
      e.Technology AS 'EmployeeTechnology', 
      pa.ProjectId,
      p.Name AS 'ProjectName',
      pa.DepartmentId, 
      d.Name AS 'DepartmentName',
      pa.StartDate, pa.EndDate, pa.AssignedForInPersents, pa.BillableForInPersents,
	  (SELECT SUM(pp.AssignedForInPersents) FROM pa_projectassignment pp WHERE pp.EmployeeId = pa.EmployeeId) AS AssignedForInPersentsSum,
      (SELECT SUM(pp.BillableForInPersents) FROM pa_projectassignment pp WHERE pp.EmployeeId = pa.EmployeeId) AS BillableForInPersentsSum

    FROM pa_projectassignment as pa
      INNER JOIN  pa_employee as e
        ON e.EmployeeId = pa.EmployeeId AND e.IsDeleted = 0
      LEFT JOIN  pa_project as p
        ON pa.ProjectId = p.Id AND p.IsDeleted = 0
      INNER JOIN  pa_department as d
        ON pa.DepartmentId = d.Id AND d.IsDeleted = 0

    WHERE (e.FullName LIKE CONCAT('%', SearchKeyword, '%')
      OR e.JobTitle LIKE CONCAT('%', SearchKeyword, '%')
      OR e.Technology LIKE CONCAT('%', SearchKeyword, '%')
      OR p.Name LIKE CONCAT('%', SearchKeyword, '%')
      OR d.Name LIKE CONCAT('%', SearchKeyword, '%') 
     )

	 AND e.FullName LIKE CONCAT('%', EmployeeFullNameFilter, '%')
     AND e.JobTitle LIKE CONCAT('%', EmployeeJobTitleFilter, '%')
     AND ((EmployeeTechnologyFilter = '' AND e.Technology IS NULL) OR e.Technology LIKE CONCAT('%', EmployeeTechnologyFilter, '%'))
     AND ((ProjectFilter = '' AND p.Name IS NULL) OR p.Name LIKE CONCAT('%', ProjectFilter, '%'))
     AND d.Name LIKE CONCAT('%', DepartmentFilter, '%')
	 AND IF(ShowOldAssignments = true, 1, pa.EndDate IS NULL OR pa.EndDate >= UTC_DATE())
     AND IF(ShowOldDeactivatedProjects = true, 1, (p.EndDate IS NULL OR p.EndDate >= UTC_DATE()) AND (p.EndDate IS NULL OR p.IsActive = true))

     -- AND e.`IsDeleted` = 0

    ORDER BY
			CASE WHEN SortColumnName = 'employeeFullName' AND IsDescending = 0 THEN e.FullName END,
			CASE WHEN SortColumnName = 'employeeFullName' AND IsDescending = 1 THEN e.FullName END DESC,
			CASE WHEN SortColumnName = 'employeeJobTitle' AND IsDescending = 0 THEN e.JobTitle END,
			CASE WHEN SortColumnName = 'employeeJobTitle' AND IsDescending = 1 THEN e.JobTitle END DESC,
			CASE WHEN SortColumnName = 'employeeTechnology' AND IsDescending = 0 THEN e.Technology END,
			CASE WHEN SortColumnName = 'employeeTechnology' AND IsDescending = 1 THEN e.Technology END DESC,
			CASE WHEN SortColumnName = 'projectName' AND IsDescending = 0 THEN p.Name END,
			CASE WHEN SortColumnName = 'projectName' AND IsDescending = 1 THEN p.Name END DESC,
			CASE WHEN SortColumnName = 'departmentName' AND IsDescending = 0 THEN d.Name END,
			CASE WHEN SortColumnName = 'departmentName' AND IsDescending = 1 THEN d.Name END DESC,
			CASE WHEN SortColumnName = 'startDateToDisplay' AND IsDescending = 0 THEN pa.StartDate END,
			CASE WHEN SortColumnName = 'startDateToDisplay' AND IsDescending = 1 THEN pa.StartDate END DESC,
			CASE WHEN SortColumnName = 'endDateToDisplay' AND IsDescending = 0 THEN pa.EndDate END,
			CASE WHEN SortColumnName = 'endDateToDisplay' AND IsDescending = 1 THEN pa.EndDate END DESC,
			CASE WHEN SortColumnName = 'assignedForInPersents' AND IsDescending = 0 THEN pa.AssignedForInPersents END,
			CASE WHEN SortColumnName = 'assignedForInPersents' AND IsDescending = 1 THEN pa.AssignedForInPersents END DESC,
			CASE WHEN SortColumnName = 'billableForInPersents' AND IsDescending = 0 THEN pa.BillableForInPersents END,
			CASE WHEN SortColumnName = 'billableForInPersents' AND IsDescending = 1 THEN pa.BillableForInPersents END DESC
  
    LIMIT CurrentPageLimit, ItemsPerPage;
END
$$

--
-- Описание для процедуры pa_projectAssignment_getTotalCount
--
DROP PROCEDURE IF EXISTS pa_projectAssignment_getTotalCount$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_projectAssignment_getTotalCount(IN SearchKeyword varchar(500),
  IN EmployeeFullNameFilter varchar(255),
  IN EmployeeJobTitleFilter varchar(255),
  IN EmployeeTechnologyFilter varchar(255),
  IN ProjectFilter varchar(255),
  IN DepartmentFilter varchar(255),
  IN ShowOldAssignments boolean,
  IN ShowOldDeactivatedProjects boolean
  )
BEGIN

  	SELECT COUNT(pa.Id)

     FROM pa_projectassignment as pa
      INNER JOIN  pa_employee as e
        ON e.EmployeeId = pa.EmployeeId AND e.IsDeleted = 0
      LEFT JOIN  pa_project as p
        ON pa.ProjectId = p.Id AND p.IsDeleted = 0
      INNER JOIN  pa_department as d
        ON pa.DepartmentId = d.Id AND d.IsDeleted = 0


    WHERE (e.FullName LIKE CONCAT('%', SearchKeyword, '%')
      OR e.JobTitle LIKE CONCAT('%', SearchKeyword, '%')
      OR e.Technology LIKE CONCAT('%', SearchKeyword, '%')
      OR e.Technology LIKE CONCAT('%', SearchKeyword, '%')
      OR p.Name LIKE CONCAT('%', SearchKeyword, '%')
      OR d.Name LIKE CONCAT('%', SearchKeyword, '%')
  )

	AND e.FullName LIKE CONCAT('%', EmployeeFullNameFilter, '%')
     AND e.JobTitle LIKE CONCAT('%', EmployeeJobTitleFilter, '%')
     AND ((EmployeeTechnologyFilter = '' AND e.Technology IS NULL) OR e.Technology LIKE CONCAT('%', EmployeeTechnologyFilter, '%'))
     AND ((ProjectFilter = '' AND p.Name IS NULL) OR p.Name LIKE CONCAT('%', ProjectFilter, '%'))
     AND d.Name LIKE CONCAT('%', DepartmentFilter, '%')
	 AND IF(ShowOldAssignments = true, 1, pa.EndDate IS NULL OR pa.EndDate >= UTC_DATE())
     AND IF(ShowOldDeactivatedProjects = true, 1, (p.EndDate IS NULL OR p.EndDate >= UTC_DATE()) AND (p.EndDate IS NULL OR p.IsActive = true));

     -- AND e.`IsDeleted` = 0
END
$$

--
-- Описание для процедуры pa_projectAssignment_update
--
DROP PROCEDURE IF EXISTS pa_projectAssignment_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_projectAssignment_update(IN Id int(11),
  IN EmployeeId char(36),
  IN ProjectId int(11),
  IN DepartmentId int(11),
  IN StartDate date,
  IN EndDate date,
  IN AssignedFor int(11),
  IN BillableFor int(11)
  )
BEGIN
  UPDATE pa_projectassignment pa
  SET EmployeeId = EmployeeId,
    ProjectId = ProjectId,
    DepartmentId = DepartmentId,
    StartDate = StartDate,
    EndDate = EndDate,
    AssignedForInPersents = AssignedFor,
    BillableForInPersents = BillableFor

  WHERE pa.Id = Id;
END
$$

--
-- Описание для процедуры pa_project_activate
--
DROP PROCEDURE IF EXISTS pa_project_activate$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_activate(
  IN Id int(11),
  IN MakeActive boolean
  )
BEGIN
  UPDATE pa_project p
  SET
    p.IsActive = MakeActive
  WHERE p.Id = Id;
END
$$

--
-- Описание для процедуры pa_project_create
--
DROP PROCEDURE IF EXISTS pa_project_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_create(
  IN Name varchar(255),
  IN Description varchar(255),
  IN StartDate datetime,
  IN EndDate datetime
  )
BEGIN
  INSERT INTO pa_project(
    Name,
    Description,
    StartDate,
    EndDate
    )
    VALUES(
    Name,
    Description,
    StartDate,
    EndDate
    );

	SELECT LAST_INSERT_ID();
END
$$

--
-- Описание для процедуры pa_project_delete
--
DROP PROCEDURE IF EXISTS pa_project_delete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_delete(
  IN Id int
  )
BEGIN
  UPDATE pa_project p
  SET
    p.IsDeleted = 1
  WHERE p.Id = Id;
END
$$

--
-- Описание для процедуры pa_project_getAll
--
DROP PROCEDURE IF EXISTS pa_project_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_getAll(
  IN CurrentPage int(1), 
  IN ItemsPerPage int(1), 
  IN SortColumnName varchar(100), 
  IN IsDescending bit, 
  IN SearchKeyword varchar(500), 
  IN ShowOld bool,
  IN ShowDeactivated bool
  )
BEGIN
   DECLARE CurrentPageLimit int(1);
    SET CurrentPageLimit = (CurrentPage - 1) * ItemsPerPage;


  	SELECT p.Id, p.Name, p.Description, p.StartDate, p.EndDate, p.IsActive

    FROM pa_project as p

    WHERE (p.Name LIKE CONCAT('%', SearchKeyword, '%')
      OR p.Description LIKE CONCAT('%', SearchKeyword, '%'))
     
      AND p.`IsDeleted` = 0
      AND IF(ShowOld = true, 1, p.EndDate IS NULL OR p.EndDate > UTC_DATE())
	  AND IF(ShowDeactivated = true, 1, p.IsActive = true)

    ORDER BY
			CASE WHEN SortColumnName = 'Name' AND IsDescending = 0 THEN p.Name END,
			CASE WHEN SortColumnName = 'Name' AND IsDescending = 1 THEN p.Name END DESC,
			CASE WHEN SortColumnName = 'Description' AND IsDescending = 0 THEN p.Description END,
			CASE WHEN SortColumnName = 'Description' AND IsDescending = 1 THEN p.Description END DESC,
			CASE WHEN SortColumnName = 'StartDate' AND IsDescending = 0 THEN p.StartDate END,
			CASE WHEN SortColumnName = 'StartDate' AND IsDescending = 1 THEN p.StartDate END DESC,
			CASE WHEN SortColumnName = 'EndDate' AND IsDescending = 0 THEN p.EndDate END,
			CASE WHEN SortColumnName = 'EndDate' AND IsDescending = 1 THEN p.EndDate END DESC
  
    LIMIT CurrentPageLimit, ItemsPerPage;
END
$$

--
-- Описание для процедуры pa_project_getAllByNameAutocomplete
--
DROP PROCEDURE IF EXISTS pa_project_getAllByNameAutocomplete$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_getAllByNameAutocomplete(
  IN NameAutocomplete varchar(20),
  IN ShowOld bool,
  IN ShowDeactivated bool
  )
BEGIN
	SELECT p.Id, p.Name, p.Description, p.StartDate, p.EndDate, p.IsActive

  FROM pa_project as p

  WHERE p.Name LIKE CONCAT('%', NameAutocomplete, '%')
    AND p.`IsDeleted` = 0
    AND IF(ShowOld = true, 1, p.EndDate IS NULL OR p.EndDate >= UTC_DATE())
	AND IF(ShowDeactivated = true, 1, p.IsActive = true);
END
$$

--
-- Описание для процедуры pa_project_getByName
--
DROP PROCEDURE IF EXISTS pa_project_getByName$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_getByName(IN Name varchar(255))
BEGIN
  SELECT p.Id, p.Name, p.Description, p.StartDate, p.EndDate, p.IsActive
  FROM pa_project p
  WHERE p.Name = Name AND p.IsDeleted = 0;
END
$$

--
-- Описание для процедуры pa_project_getTotalCount
--
DROP PROCEDURE IF EXISTS pa_project_getTotalCount$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_getTotalCount(
  IN SearchKeyword varchar(500),
  IN ShowOld bool
  )
BEGIN
	SELECT COUNT(p.Id)

    FROM pa_project as p

    WHERE (p.Name LIKE CONCAT('%', SearchKeyword, '%')
      OR p.Description LIKE CONCAT('%', SearchKeyword, '%'))
      AND IF(ShowOld = true, 1, p.EndDate IS NULL OR p.EndDate >= UTC_DATE())
      AND p.`IsDeleted` = 0;
END
$$

--
-- Описание для процедуры pa_project_update
--
DROP PROCEDURE IF EXISTS pa_project_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE pa_project_update(
  IN Id int,
  IN Name varchar(255),
  IN Description varchar(255),
  IN StartDate datetime,
  IN EndDate datetime
  )
BEGIN
  UPDATE pa_project p
  SET
    p.Name = Name,
    p.Description = Description,
    p.StartDate = StartDate,
    p.EndDate = EndDate
  WHERE p.Id = Id;
END
$$

DELIMITER ;

-- 
-- Вывод данных для таблицы aspnetroles
--
INSERT INTO aspnetroles VALUES
('05c398b1-0134-4282-8e28-ad2d6b1c867c', 'SuperAdmin'),
('07395294-a603-48d1-891b-4cfb74e7bfae', 'Manager'),
('59227c63-bf62-4dd2-8096-aae05d55e1b3', 'Employee'),
('62e5eedb-b179-45f7-a2bd-20e24d8c6ab5', 'Recruiter'),
('78bb8c33-fb25-4562-8d08-479d4aeb4a74', 'Admin');

-- 
-- Вывод данных для таблицы aspnetusers
--
INSERT INTO aspnetusers VALUES
('81bcf38b-02e2-4c12-8994-1982a4aad084', 'Olha D', 0, 'AFuOZ4yLC/3OHd+kUbf+sxonSho3QApMbXvKa3bpdJ15Xq2GzA78U97oGMkwSnIyxQ==', '82cfe1ba-da68-40f8-8f3c-7be7d1721e9c', '1234', 0, 0, NULL, 1, 0, 'user'),
('8dcdc093-8223-45b6-abd0-29ef2f89193f', 'Olha Dorozhko1', 1, 'kl0um7NnnBud1YqyC7l0/cYfP/TbXhK7VPqwYAJhx7M=', '1e05aa8c-482c-43a2-a22b-92c88797021e', '12345s', 1, 0, NULL, 1, 5, 'user1@gmail.com'),
('dd52ff23-b666-4c93-a4ad-b2786bf5f367', 'e', 0, 'AMv8P9O4Ewz8BmIA59Zvl2PQ+e99NHFvAa5BXTiNJTxk6dpcQuRJBcaxcEM2ILO5IQ==', '35bebef5-7df1-486c-b6d5-89c3661f92bc', NULL, 0, 0, NULL, 1, 0, 'test@t.com'),
('dsf', 'Olha3', 1, 'fds', 'da2fa92d-59fe-40ce-a4ac-8626dd0d0343', '2', 1, 1, NULL, 1, 4, 'user2@gmail.com');

-- 
-- Вывод данных для таблицы clients
--
INSERT INTO clients VALUES
('ngAuthApp', '5YV7M1r981yoGhELyB84aC+KiYksxZf1OY3++C1CtRM=', 'AngularJS front-end Application', True, 7200, NULL);

-- 
-- Вывод данных для таблицы core_jobtitle
--
INSERT INTO core_jobtitle VALUES
(7, 'Developer', 0),
(8, 'QA', 1),
(9, 'Manager', 0);

-- 
-- Вывод данных для таблицы core_officelocation
--
INSERT INTO core_officelocation VALUES
(1, 'Ukraine', 'Kharkiv'),
(2, 'Ukraine', 'Lviv');

-- 
-- Вывод данных для таблицы core_technology
--
INSERT INTO core_technology VALUES
(1, 'as', 0),
(2, 'd', 0),
(3, 'dsf33', 1);

-- 
-- Вывод данных для таблицы messagesaudit
--
INSERT INTO messagesaudit VALUES
(1, '{"EmployeeId":"ef7a848f-d7f8-4441-8820-bc0c5cb47e7f","FullName":"test","JobTitle":"qa","Technology":null,"StartDate":"2017-04-17T00:00:00","EventId":"caa50000-3418-902b-ecbd-08d497845dae"}', '{"MessageId":"caa50000-3418-902b-ecbd-08d497845dae","ConversationId":"caa50000-3418-902b-2110-08d497845db1","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnensgswbdkjxbnaya?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-10', 58),
(2, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","FullName":"Olha Dorozhko","JobTitle":"Developer2","Technology":null,"StartDate":"2017-02-25T00:00:00","EventId":"caa50000-3418-902b-ee02-08d49785ce20"}', '{"MessageId":"caa50000-3418-902b-ee02-08d49785ce20","ConversationId":"caa50000-3418-902b-4e2c-08d49785ce23","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenz551bdkjxbqmyq?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-10', 28),
(3, '{"EmployeeId":"9a6e2e47-e358-4709-9b8e-3ec545a398e2","FullName":"Test","JobTitle":"1","Technology":null,"StartDate":"2017-05-09T21:00:00Z","EventId":"caa50000-3418-902b-e2e0-08d497963ab1"}', '{"MessageId":"caa50000-3418-902b-e2e0-08d497963ab1","ConversationId":"caa50000-3418-902b-460a-08d497963ab4","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzg87bdkjxr9hgs?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeCreatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-05-10', 18),
(4, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","FullName":"Olha Dorozhko","JobTitle":"Developer2","Technology":null,"StartDate":"2017-02-24T00:00:00","EventId":"caa50000-3418-902b-d13b-08d4b1969034"}', '{"MessageId":"caa50000-3418-902b-d13b-08d4b1969034","ConversationId":"caa50000-3418-902b-071b-08d4b1969037","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-iisexpress-3k1oyybwdnenzz5ybdkmdftk8w?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-12', 40),
(5, '{"EmployeeId":"4f3fad2e-d303-43f1-8867-75df9fb379d0","EventId":"caa50000-3418-902b-3fa4-08d4b1969585"}', '{"MessageId":"caa50000-3418-902b-3fa4-08d4b1969585","ConversationId":"caa50000-3418-902b-6783-08d4b1969585","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-iisexpress-3k1oyybwdnenzz5ybdkmdftk8w?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeDeletedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-12', 40),
(6, '{"EmployeeId":"a6850ddd-62c5-47ab-a344-98206453300a","FullName":"sdf","JobTitle":"df","Technology":null,"StartDate":"2017-06-13T21:00:00Z","EventId":"caa50000-3418-902b-e8df-08d4b971099e"}', '{"MessageId":"caa50000-3418-902b-e8df-08d4b971099e","ConversationId":"caa50000-3418-902b-3dd9-08d4b97109a1","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzexibdkm15zddt?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeCreatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-22', 18),
(7, '{"EmployeeId":"a6850ddd-62c5-47ab-a344-98206453300a","FullName":"sdf","JobTitle":"df","Technology":null,"StartDate":"2017-06-13T00:00:00","EventId":"caa50000-3418-902b-11c9-08d4b97110ff"}', '{"MessageId":"caa50000-3418-902b-11c9-08d4b97110ff","ConversationId":"caa50000-3418-902b-3f81-08d4b97110ff","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzexibdkm15zddt?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-22', 18),
(8, '{"EmployeeId":"21bc617c-30e8-4795-ad21-324d99808b97","FullName":"TEst","JobTitle":"dd","Technology":null,"StartDate":"2017-06-07T21:00:00Z","EventId":"caa50000-3418-902b-d6f6-08d4b9a4ee6c"}', '{"MessageId":"caa50000-3418-902b-d6f6-08d4b9a4ee6c","ConversationId":"caa50000-3418-902b-6cdd-08d4b9a4ee6f","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzn4pbdkmuekpgi?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeCreatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-22', 16),
(9, '{"EmployeeId":"21bc617c-30e8-4795-ad21-324d99808b97","FullName":"TEst","JobTitle":"dd","Technology":null,"StartDate":"2017-06-07T00:00:00","EventId":"caa50000-3418-902b-0190-08d4b9a4f834"}', '{"MessageId":"caa50000-3418-902b-0190-08d4b9a4f834","ConversationId":"caa50000-3418-902b-4244-08d4b9a4f834","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzn4pbdkmuekpgi?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-22', 16),
(10, '{"EmployeeId":"21bc617c-30e8-4795-ad21-324d99808b97","FullName":"TEst","JobTitle":"dd","Technology":null,"StartDate":"2017-06-06T00:00:00","EventId":"caa50000-3418-902b-6e12-08d4b9a51d21"}', '{"MessageId":"caa50000-3418-902b-6e12-08d4b9a51d21","ConversationId":"caa50000-3418-902b-707a-08d4b9a51d21","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzn4pbdkmuekpgi?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-22', 16),
(11, '{"EmployeeId":"21bc617c-30e8-4795-ad21-324d99808b97","EventId":"caa50000-3418-902b-193f-08d4b9a526e5"}', '{"MessageId":"caa50000-3418-902b-193f-08d4b9a526e5","ConversationId":"caa50000-3418-902b-4411-08d4b9a526e5","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzn4pbdkmuekpgi?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeDeletedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-22', 16),
(12, '{"EmployeeId":"21bc617c-30e8-4795-ad21-324d99808b97","FullName":"TEst","JobTitle":"dd","Technology":"Android","StartDate":"2017-06-05T00:00:00","EventId":"caa50000-3418-902b-6ab5-08d4b9a55407"}', '{"MessageId":"caa50000-3418-902b-6ab5-08d4b9a55407","ConversationId":"caa50000-3418-902b-6c22-08d4b9a55407","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzn4pbdkmuekpgi?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-22', 16),
(13, '{"EmployeeId":"21bc617c-30e8-4795-ad21-324d99808b97","FullName":"TEst","JobTitle":"dd","Technology":"Android","StartDate":"2017-06-04T00:00:00","EventId":"caa50000-3418-902b-669d-08d4b9a563f7"}', '{"MessageId":"caa50000-3418-902b-669d-08d4b9a563f7","ConversationId":"caa50000-3418-902b-6870-08d4b9a563f7","CorrelationId":null,"InitiatorId":null,"RequestId":null,"SourceAddress":"rabbitmq://localhost/bus-CP029-w3wp-3k1oyybwdnenzn4pbdkmuekpgi?durable=false&autodelete=true","DestinationAddress":"rabbitmq://localhost/HRTools.Crosscutting.Messaging.Events.Employee:EmployeeUpdatedEvent","ResponseAddress":null,"FaultAddress":"rabbitmq://localhost/teaminternational_errors","ContextType":"Consume","Headers":{},"Custom":null}', '2017-06-22', 16);

-- 
-- Вывод данных для таблицы pa_department
--
INSERT INTO pa_department VALUES
(1, 'Development', NULL, 0),
(2, 'QA', NULL, 0);

-- 
-- Вывод данных для таблицы pa_employee
--
INSERT INTO pa_employee VALUES
(13, '21bc617c-30e8-4795-ad21-324d99808b97', 'TEst', 'dd', 'Android', '2017-06-04', 0);

-- 
-- Вывод данных для таблицы pa_project
--
INSERT INTO pa_project VALUES
(1, 'Hr Tools', NULL, '2017-03-06', NULL, 1, 0),
(2, 'dsf', NULL, '2017-03-05', NULL, 1, 0),
(3, 'dd', NULL, '2017-06-12', NULL, 1, 0);

-- 
-- Вывод данных для таблицы pa_projectassignment
--
INSERT INTO pa_projectassignment VALUES
(1, '4f3fad2e-d303-43f1-8867-75df9fb379d0', NULL, 1, '2018-05-15', NULL, 34, 5),
(2, '8c419943-6a9a-444f-9c8b-d4a4fe9b1dd9', NULL, 1, '2017-06-11', NULL, 100, 32);

-- 
-- Вывод данных для таблицы refreshtokens
--
INSERT INTO refreshtokens VALUES
('69BZ+1+jW5IrAAHd4uBwKzXn94fE2GcVycPqyk0cjys=', 'user', 'ngAuthApp', '2017-06-22 19:20:58', '2017-06-27 19:20:58', 'FSElj2VejBrv9fY00qnWDF5O5SGz1hxmMlWf7H-pNuH39tp_YDWBGChHhChcjaW12A0ltTNcz3cFMXwU0jXMrp4i0aFujUAWPRfc0rhs_xsJB2JeFCFe4iynFtQWG6B9WUR71HUGhsUiwRUHnap-b1Z8gA_t_HjAWsh-ChiZkZ4P7F8naxvBIHRU8FM3i1Md3X07v0KW1RkhgiLleHubJhJ0OSDkxfeeiztIZyPXjwrqh4UTvVFOf0VDlDN2T2sub9QsArrEjHuViLHLtpFV427NybdDyb1scOB30K3h_5o82nyLHdoYJFn-hZIFPoNuMtCPDKFQw0rtWGxahd4kO1bb9wvQwhqS0ngJ5pkrX2b5nLwXVsYjWNvU9eobUlGa_xrZ8CcYkc-kdaLOEGWwnQ');

-- 
-- Вывод данных для таблицы aspnetuserclaims
--
INSERT INTO aspnetuserclaims VALUES
(15, '81bcf38b-02e2-4c12-8994-1982a4aad084', 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role', 'Admin'),
(16, 'dd52ff23-b666-4c93-a4ad-b2786bf5f367', 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role', 'Employee'),
(17, 'dd52ff23-b666-4c93-a4ad-b2786bf5f367', 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role', 'Admin'),
(33, '81bcf38b-02e2-4c12-8994-1982a4aad084', 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role', 'Employee'),
(35, '8dcdc093-8223-45b6-abd0-29ef2f89193f', 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role', 'Employee'),
(36, '8dcdc093-8223-45b6-abd0-29ef2f89193f', 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role', 'Admin'),
(40, 'dsf', 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role', 'Employee');

-- 
-- Вывод данных для таблицы aspnetuserlogins
--

-- Таблица team_international.aspnetuserlogins не содержит данных

-- 
-- Вывод данных для таблицы aspnetuserroles
--
INSERT INTO aspnetuserroles VALUES
('dd52ff23-b666-4c93-a4ad-b2786bf5f367', '05c398b1-0134-4282-8e28-ad2d6b1c867c'),
('8dcdc093-8223-45b6-abd0-29ef2f89193f', '59227c63-bf62-4dd2-8096-aae05d55e1b3'),
('dd52ff23-b666-4c93-a4ad-b2786bf5f367', '59227c63-bf62-4dd2-8096-aae05d55e1b3'),
('dsf', '59227c63-bf62-4dd2-8096-aae05d55e1b3'),
('81bcf38b-02e2-4c12-8994-1982a4aad084', '78bb8c33-fb25-4562-8d08-479d4aeb4a74'),
('8dcdc093-8223-45b6-abd0-29ef2f89193f', '78bb8c33-fb25-4562-8d08-479d4aeb4a74'),
('dd52ff23-b666-4c93-a4ad-b2786bf5f367', '78bb8c33-fb25-4562-8d08-479d4aeb4a74');

-- 
-- Вывод данных для таблицы core_employee
--
INSERT INTO core_employee VALUES
(57, '21bc617c-30e8-4795-ad21-324d99808b97', 'TEst', NULL, NULL, 'dd', 'df', NULL, 'Android', 'tes', NULL, 'dfsdf@jdsf.cd', NULL, NULL, '', NULL, NULL, NULL, 0, '2017-06-03', NULL, 0, NULL, NULL, NULL, 1, NULL, 0);

-- 
-- Восстановить предыдущий режим SQL (SQL mode)
-- 
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;