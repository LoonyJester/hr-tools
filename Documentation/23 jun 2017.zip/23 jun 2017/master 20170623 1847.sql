﻿--
-- Скрипт сгенерирован Devart dbForge Studio for MySQL, Версия 7.2.53.0
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 6/23/2017 6:47:37 PM
-- Версия сервера: 5.7.17-log
-- Версия клиента: 4.1
--


-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установить режим SQL (SQL mode)
-- 
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

-- 
-- Установка базы данных по умолчанию
--
USE master;

--
-- Описание для таблицы configuration
--
DROP TABLE IF EXISTS configuration;
CREATE TABLE configuration (
  Id INT(11) NOT NULL,
  ClientId CHAR(36) NOT NULL,
  ConnectionString VARCHAR(400) NOT NULL,
  ActiveModules TEXT DEFAULT NULL,
  PRIMARY KEY (Id)
)
ENGINE = INNODB
AVG_ROW_LENGTH = 8192
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

--
-- Описание для таблицы modulesconfiguration
--
DROP TABLE IF EXISTS modulesconfiguration;
CREATE TABLE modulesconfiguration (
  Id INT(11) NOT NULL AUTO_INCREMENT,
  ClientId CHAR(36) NOT NULL,
  ModuleName VARCHAR(255) NOT NULL,
  StartDate DATE NOT NULL,
  EndDate DATE DEFAULT NULL,
  PRIMARY KEY (Id),
  UNIQUE INDEX Id (Id)
)
ENGINE = INNODB
AUTO_INCREMENT = 67
AVG_ROW_LENGTH = 5461
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = DYNAMIC;

DELIMITER $$

--
-- Описание для процедуры master_configuration_getAll
--
DROP PROCEDURE IF EXISTS master_configuration_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE master_configuration_getAll()
BEGIN 
    SELECT c.Id, c.ClientId, c.ConnectionString, c.ActiveModules 
    FROM   configuration as c;
END
$$

--
-- Описание для процедуры master_configuration_getByClientId
--
DROP PROCEDURE IF EXISTS master_configuration_getByClientId$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE master_configuration_getByClientId(IN ClientId char(36))
BEGIN 
    SELECT DISTINCT
    c.Id,
    c.ClientId,
    c.ConnectionString,
    c.ActiveModules
  FROM configuration AS c
    INNER JOIN modulesconfiguration mc
      ON c.ClientId = mc.ClientId
  WHERE c.ClientId = ClientId
  AND mc.StartDate <= CURDATE()
  AND (mc.EndDate IS NULL
  OR mc.EndDate >= CURDATE());
END
$$

--
-- Описание для процедуры master_modulesconfiguration_create
--
DROP PROCEDURE IF EXISTS master_modulesconfiguration_create$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE master_modulesconfiguration_create(IN ClientId char(36) , IN ModuleName varchar(255), IN StartDate date, IN EndDate date)
BEGIN
  INSERT INTO modulesconfiguration (
    ClientId,
  ModuleName,
  StartDate,
  EndDate)
    VALUES (ClientId, ModuleName, StartDate, EndDate);

	SELECT LAST_INSERT_ID();
END
$$

--
-- Описание для процедуры master_modulesconfiguration_getActiveModulesByClientId
--
DROP PROCEDURE IF EXISTS master_modulesconfiguration_getActiveModulesByClientId$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE master_modulesconfiguration_getActiveModulesByClientId(IN ClientId char(36))
BEGIN
  SELECT
    mc.ModuleName
  FROM modulesconfiguration mc
  WHERE mc.ClientId = ClientId
  AND mc.StartDate <= CURDATE()
  AND (mc.EndDate IS NULL
  OR mc.EndDate >= CURDATE());
END
$$

--
-- Описание для процедуры master_modulesconfiguration_getAll
--
DROP PROCEDURE IF EXISTS master_modulesconfiguration_getAll$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE master_modulesconfiguration_getAll(IN ClientId char(36), IN ShowOld boolean)
BEGIN
  SELECT mc.Id, mc.ClientId, mc.ModuleName, mc.StartDate, mc.EndDate
  FROM modulesconfiguration mc
  WHERE mc.ClientId = ClientId
    AND IF(ShowOld = TRUE, 1, (mc.EndDate IS NULL OR mc.EndDate >= CURDATE()));
END
$$

--
-- Описание для процедуры master_modulesconfiguration_update
--
DROP PROCEDURE IF EXISTS master_modulesconfiguration_update$$
CREATE DEFINER = 'root'@'localhost'
PROCEDURE master_modulesconfiguration_update(IN Id int(11), IN ClientId char(36), IN ModuleName varchar(255), IN StartDate date, IN EndDate date)
BEGIN
  UPDATE modulesconfiguration mc
  SET 
    mc.ModuleName = ModuleName,
    mc.StartDate = StartDate,
    mc.EndDate = EndDate
  WHERE mc.Id = Id AND mc.ClientId = ClientId;
END
$$

DELIMITER ;

-- 
-- Вывод данных для таблицы configuration
--
INSERT INTO configuration VALUES
(1, 'a4260c2b-3d9d-436b-ba99-b6667a374b89', 'Server=localhost;Database=team_international;Uid=root;Pwd=Welcome123;AutoEnlist=false', 'Core,PA,ATS'),
(2, '9a0c9793-9064-48b0-b38f-58071d0f52e1', 'Server=localhost;Database=company;Uid=root;Pwd=Welcome123;AutoEnlist=false', NULL);

-- 
-- Вывод данных для таблицы modulesconfiguration
--
INSERT INTO modulesconfiguration VALUES
(1, 'a4260c2b-3d9d-436b-ba99-b6667a374b89', 'Core', '2017-05-09', NULL),
(2, '9a0c9793-9064-48b0-b38f-58071d0f52e1', 'Core', '2017-05-01', NULL),
(60, '9a0c9793-9064-48b0-b38f-58071d0f52e1', 'Project Assignment', '2017-04-26', '2017-04-26'),
(61, 'a4260c2b-3d9d-436b-ba99-b6667a374b89', 'Project Assignment', '2017-04-26', '2017-05-31'),
(62, 'a4260c2b-3d9d-436b-ba99-b6667a374b89', 'ATS', '2017-04-11', '2017-05-31'),
(65, 'a4260c2b-3d9d-436b-ba99-b6667a374b89', 'Project Assignment', '2017-06-11', NULL),
(66, 'a4260c2b-3d9d-436b-ba99-b6667a374b89', 'ATS', '2017-06-22', NULL);

-- 
-- Восстановить предыдущий режим SQL (SQL mode)
-- 
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;